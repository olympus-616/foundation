# EOS-3 Roadmap Findings

**Attestation run:** 2026-06-11
**Verdict (Phase 1, control-plane only):** PASS — system rebuilds from GitHub end-to-end; control plane responds at :615 + :616 with 31 idle gods registered.
**Phase 2 (full-stack — scratch org → pantheon → data flow → omens):** in progress at time of writing.
**Findings:** numbered list below. Severity scale: **blocker** (cannot rebuild without founder), **high** (rebuild requires undocumented manual step), **medium** (works on this host but won't on a fresh one), **low** (cosmetic, documentation).

Each finding carries a compliance-control tag set so the same evidence supports SOC-2, HIPAA, PCI DSS, and ISO 27001 audits without re-mapping. See `EOS_FRAMEWORK.md` § Compliance Mapping for the full control crosswalk.

**Compliance tag legend:**
- `SOC2:CCx.y` — Trust Services Criteria
- `HIPAA:§164.xxx` — Security Rule citations (only if PHI is in scope)
- `PCI:Reqx.y` — PCI DSS v4 requirements (only if PAN is in scope)
- `ISO27001:A.x.y` — Annex A control numbers

---

## Finding #1 — Build recipe assumes Claude Code as prerequisite

**Severity:** high
**Compliance:** `SOC2:CC2.1` `SOC2:CC8.1` `ISO27001:A.5.1` `ISO27001:A.12.1.2` `PCI:Req6.3.2`
**Where:** `alchemisthomer.sh:1932` (final line: `exec bash master-launch.1.7.x.x.sh`), `master-launch.1.7.x.x.sh:107` (final line: `claude --dangerously-skip-permissions ...`)

Every mode of `alchemisthomer.sh` ends by spawning a Claude Code session whose job is to actually run `build.sh` and `run.sh`. The build steps live in a system-prompt body, not in a shell script. A reviewer without `claude` on `PATH` cannot stand up the system via the documented entry point.

**Fix:** Factor a `bootstrap.sh` that runs STEP 0–STEP 4 (cp .env, fetch missing submodules, build, run, verify) and have `alchemisthomer.sh` call it before exec'ing claude. The Claude session then attaches to a running system rather than booting it.

**Reproducibility-from-the-void score:** Currently fails this check. After the fix it passes.

---

## Finding #2 — Submodule URLs hardcoded to SSH

**Severity:** blocker (for token-only reproducibility)
**Compliance:** `SOC2:CC6.1` `SOC2:CC6.6` `ISO27001:A.5.15` `ISO27001:A.8.2`
**Where:** `olympus-616/.gitmodules` (37 of 38 entries use `git@github.com:` SSH URLs; only `olympus-grid-www` is HTTPS).

A reviewer with only a GitHub token (no SSH key trusted on github.com) hits `Permission denied (publickey)` immediately on `--recurse-submodules`. The attestation worked around this by setting an attestation-local `GIT_CONFIG_GLOBAL` that rewrites `git@github.com:` → `https://github.com/` and supplies the token via `GIT_ASKPASS`.

**Fix:** Convert `.gitmodules` URLs to `https://github.com/...`. Submodule cloning then works for any party with read access via any auth method. SSH and HTTPS clones produce identical content; the URL choice only affects auth surface.

**Reproducibility-from-the-void score:** Cannot rebuild from a token alone today. Trivial to fix.

---

## Finding #3 — README claims `git clone --recursive` is sufficient; in practice it isn't

**Severity:** high
**Compliance:** `SOC2:CC2.1` `SOC2:CC8.1` `ISO27001:A.5.10` `HIPAA:§164.316(b)(1)`
**Where:** `README.md:40` (Quick Start §Clone)

The README presents `git clone --recursive https://github.com/olympus-616/olympus-616.git` as the entry step. On a host without SSH trust (or with a misconfigured SSH config — see Finding #2), this command silently fails for 37 of 38 submodules. The downstream `./olympus.sh` is documented to retry the fetch, but the README's "one clone" claim is materially wrong for fresh hosts.

**Fix:** Either resolve Finding #2 (preferred), or update the README to show the token-based clone recipe with `GIT_ASKPASS` / `url.insteadOf`.

---

## Finding #4 — npm audit reports 10 vulnerabilities, 2 critical at root

**Severity:** medium (SOC-2 must address)
**Compliance:** `SOC2:CC7.1` `SOC2:CC7.2` `ISO27001:A.8.8` `ISO27001:A.12.6.1` `HIPAA:§164.308(a)(8)` `PCI:Req6.2` `PCI:Req11.3`
**Where:** root `package.json` (2 critical), `api/package.json` (3 moderate + 1 high), `ui/package.json` (1 moderate + 3 high).

`bash build.sh` succeeds but `npm ci` reports 10 vulnerabilities total. SOC-2 SOC-2 controls (CC7.1, CC7.2) require a vulnerability-management program. The critical-severity issues at root must be resolved before audit submission.

**Fix:** Run `npm audit fix` at each package root, commit the resulting lock-file changes, re-run `bash build.sh` to confirm clean. If `npm audit fix --force` is required (breaking changes), evaluate the affected transitive deps and pin or replace as needed.

---

## Finding #5 — Delphi UI port misconfigured

**Severity:** low
**Compliance:** `SOC2:CC8.1` `ISO27001:A.12.1.2`
**Where:** `pantheon.json` (or wherever Delphi's `ui` URL is defined).

`GET http://localhost:615/api/gods` shows Delphi's UI port as `60722` instead of `3722` (per the README port table). Any future Launch action on Delphi will fail to bind or to be reached on the expected port.

**Fix:** Search for `60722` in the repo and correct to `3722`.

```
{
  "name": "delphi",
  "endpoints": {
    "api": { "url": "http://localhost:3721" },
    "ui":  { "url": "http://localhost:60722" }   <-- typo
  }
}
```

---

## Finding #6 — `bash build.sh` cleaned 165 orphaned node processes from prior runs

**Severity:** medium (host-state hygiene; would be **low** on a clean host)
**Compliance:** `SOC2:CC7.1` `SOC2:CC7.4` `ISO27001:A.8.16` `HIPAA:§164.312(b)`
**Where:** `build.sh:kill_olympus_zombies`

The build script's own message reports it killed 165 olympus-616 node processes from prior dev sessions. The mechanism is correct (defensive), but the magnitude (165) suggests historical sessions leaked processes without cleanup. On a fresh host this would be 0; the finding is recorded because (a) it surfaced this attestation's "from the void" framing isn't strictly true on Gregory's existing host — the previous installation tree had been renamed but worker processes were still alive — and (b) SOC-2 monitoring should detect process leaks earlier than build-time.

**Fix:** Add to `run.sh` (or a separate `stop.sh`) a graceful shutdown path that survives session-close. Long-term: ship a `launchctl`/`systemd` unit so the launcher is supervised, not orphaned.

---

## Finding #7 — Credential-trust scope and external reproducibility

**Severity:** medium (process-completeness)
**Compliance:** `SOC2:CC1.4` `SOC2:CC2.3` `SOC2:CC6.1` `ISO27001:A.5.2` `ISO27001:A.5.16` `HIPAA:§164.308(a)(3)`
**Where:** attestation methodology, not code.

This run was performed under @alchemisthomer's GitHub credentials. The process independence (no use of `alchemisthomer.sh`, no Gregory intervention beyond initial direction) is established, but credential independence is not. A truly "from the void" rebuild requires a fresh GitHub identity granted scope-limited access.

**Fix:** Schedule a second attestation run under a scope-limited service identity (e.g., a fine-grained PAT issued to `eos3-auditor` with read-only scope on the relevant 46 private repos). Compare the build artifact hashes. If identical, both runs are evidence for SOC-2.

---

## Finding #8 — `loadDevEnterpriseScratchOrg.sh` flags 4 manual configurations

**Severity:** high
**Compliance:** `SOC2:CC8.1` `SOC2:CC2.1` `ISO27001:A.5.1` `ISO27001:A.12.1.2` `PCI:Req6.3.2`
**Where:** `olympus-616/olympus-grid/scripts/bash/env/loadDevEnterpriseScratchOrg.sh` (REMINDER block, lines ~50–55)

The script itself embeds a reminder block stating that four configurations *cannot* be performed by the script and must be done by hand in Salesforce Setup after the scratch org is created:

1. Set `PortalSiteUrlRewriter` under Force.com Site Settings (not API-accessible).
2. Set logout URL in Network settings (must be an absolute URL).
3. Verify guest user email for Web2Case outbound email support.
4. Add the correct Azure redirect URL for Microsoft login in Azure App Registration.

For "from the void" SOC-2 evidence, every one of these is a checkbox the external human must complete and we cannot easily verify they did.

**Fix:** For each, evaluate in this priority order:
1. **Metadata API automation** — if the configuration *is* available via metadata API (the script comment is from one author's perspective; check current API support).
2. **Headless browser automation** — Playwright/Selenium against the Setup UI. Yes, brittle, but reproducible.
3. **Documented manual step in `RUNBOOK-FROM-THE-VOID.md`** with screenshots — explicit acceptance of the gap.

---

## Finding #20 — `ApiRouteIdentityKeyResolver` Apex returns 500 on EVERY dev-key resolution in the fresh scratch org

**Severity:** blocker (gates §2.4 olympus-gpt acceptance; any surface that authenticates via og_live_ key 401s)
**Compliance:** `SOC2:CC6.1` `SOC2:CC7.1` `SOC2:CC7.2` `SOC2:CC8.1` `ISO27001:A.5.16` `ISO27001:A.8.16` `HIPAA:§164.312(a)(1)` `HIPAA:§164.312(d)` `PCI:Req8.2` `PCI:Req10.7`
**Where:** `olympus-grid/force-app/idp/idp-api/default/classes/ApiRouteIdentityKeyResolver.cls` in the dev_enterprise scratch org.

Direct curl against the cluster confirmed via attesting-agent test (2026-06-11T~18:25Z), bypassing the gpt SPA entirely:

```
$ curl -X POST -H "x-og-key: og_live_<redacted>" \
       -d '{"prompt":"ping"}' \
       https://api-eos-3-agent-verification.turtleshell.ai/v1/athena/chat
{"error":"invalid api key","reason":"resolver_500"}    # HTTP 401

$ curl -H "x-og-key: og_live_<redacted>" \
       https://api-eos-3-agent-verification.turtleshell.ai/v1/grid/clusters/me
{"error":"invalid api key","reason":"resolver_500"}    # HTTP 401

$ curl https://api-eos-3-agent-verification.turtleshell.ai/v1/athena/health
{"ok":true}                                            # HTTP 200
```

Cluster is healthy. Middleware (`ares/api/src/middleware/apiKeyMiddleware.ts`) is correctly forwarding the key to `{hermes}/v1/grid/master/internal/identity/key-resolve`. Hermes is correctly proxying to the scratch org. **The Apex resolver in the scratch org throws an unhandled exception** and SF returns HTTP 500, which `apiKeyMiddleware.ts` translates to `reason: 'resolver_500'`.

Pre-state check at attestation time:
- `IdentityKey__c`: COUNT = 1 (the Steward-created dev key persisted to the scratch org)
- `IdentityToken__c`: COUNT = 7 (from prior resolver attempts during this attestation)

So the dev key IS in the scratch org. The resolver is finding it and failing somewhere afterwards.

Most likely root causes given Phase 2's schema-drift evidence (Finding #10):
1. **`Crypto.signWithCertificate('SHA256', ..., 'OG_Signing_Key')` fails** because the cert metadata didn't deploy cleanly into the scratch org (the cert was retrieved into `force-app/idp/default/certs/` and copied to `ares/api/certs/`, but the SF-side `Certificate.OG_Signing_Key` MAY not be a fully-installable metadata type on scratch orgs without manual re-upload).
2. **Schema drift from Finding #10's swallowed errors** — `WorkingState__c`, `ProcessQueue__c`, `ObjectStorage__c`, etc. were missing during deploy_bpm / deploy_proteus. If the resolver path touches BPM-queueable code or Proteus dynamic objects (it might queue an IdentityToken__c insert through Chronos), the compile failures cascade.
3. **A required field on `IdentityToken__c` that's missing or has a validation rule** the resolver doesn't satisfy. Insert fails → 500.

### Diagnosis path (UPDATED — root cause located, see Finding #21)

The attesting agent traced the resolver_500 to a precise root cause: **Hermes' `/v1/grid/master` proxy handler does not honor the `"unmanaged"` namespace sentinel**, so it builds an upstream SF URL with `/unmanaged/` inserted, which SF cannot resolve. The resolver Apex itself is healthy (8/8 tests pass; direct curl to the correct URL returns valid+JWT). See Finding #21 for the smoking-gun curl reproduction and the precise one-line fix.

This finding (#20) remains open as the operator-facing surface symptom; Finding #21 is the underlying defect. When #21 ships, #20 closes automatically. The diagnostic process — anonymous Apex testing, test-class re-run, direct REST curl with auth bypass — should be captured as a runbook section under "Phase B common diagnostic patterns" for future cycles.

### EOS-3 §2.4 impact

This is a clean §2.4 blocker. The acceptance gate is a `Feedback__c` row with `Source__c='olympus-gpt'`. The gpt UI cannot reach Athena (or any other auth-required endpoint) because of this resolver failure, so the user cannot complete the chat that would precede the feedback submission. Whether the feedback submission itself bypasses the apiKeyMiddleware (e.g., if Feedback__c POST is anonymous-friendly) is an open question worth checking — if so, §2.4 may still be achievable through a feedback-only path while this finding is open.

---

## Finding #24 — Athena's Local LLM provider fails on freshly-spawned clusters; chat returns `internal_error: 'Local LLM failed to respond.'`

**Status: REVISED 2026-06-11T20:53Z — root cause was the attesting agent's curl missing `agentId: 'athena'` in the body, NOT a provider config gap.**

**Severity (revised):** medium (still real: the default-no-agentId path falls through to Ollama which isn't configured on the cluster — observable, but never exercised by gpt-SPA clients which always set `agentId`)
**Compliance:** `SOC2:CC2.1` `SOC2:CC7.1` `SOC2:CC8.1` `ISO27001:A.5.10` `ISO27001:A.8.16` `ISO27001:A.12.1.2`
**Where:** Athena god service running in the spawned Pantheon cluster — likely missing/misconfigured local-LLM (Ollama) provider configuration in the cluster's runtime environment.

After Finding #21 was fixed and shipped, the §2.4 attestation verified the auth chain end-to-end:

```
$ curl -X POST -H "x-og-key: og_live_<redacted>" \
       -d '{"prompt":"ping"}' \
       https://api-eos-3-agent-verification-2.turtleshell.ai/v1/athena/chat

HTTP 200
event: metadata
data: {"requestId":"d30b45be-0e76-4101-8322-564369fb18f1","conversationId":"fd460a73-f8c4-40fb-b0e5-6d07573b8bdf"}

event: message
data: {"type":"error","code":"internal_error","content":"Local LLM failed to respond.","data":{}}
```

What this tells us:
- ✅ Dev key was accepted by Ares apiKeyMiddleware (Finding #21 fix shipped).
- ✅ Hermes proxied to SF correctly (the `unmanaged` sentinel fix from PR #57 worked).
- ✅ Apex resolver minted a valid JWT and Ares forwarded it.
- ✅ Athena received the authenticated request and started processing (returned a `requestId` and `conversationId`).
- ❌ Athena's local LLM call failed. Surface error is `Local LLM failed to respond.` — implies Athena's runtime is configured to use a local provider (Ollama) but the call to it failed (Ollama not running on the cluster, or Athena's `OLLAMA_BASE_URL` points somewhere unreachable from the cluster, or the model isn't pulled).

This is consistent with the local development setup (where `alchemisthomer.sh` does an Ollama preflight including installing Ollama, pulling a model, and verifying responsiveness — see `alchemisthomer.sh:1700–1820`). The cluster does NOT run that preflight. The Pantheon container probably ships with no LLM provider configured by default — operators are expected to either:
1. Set `OPENAI_API_KEY` / `ANTHROPIC_API_KEY` / `XAI_API_KEY` SSM parameters so Athena uses a cloud LLM, OR
2. Embed an Ollama runtime in the Pantheon image and pre-pull a model, OR
3. Point Athena at a remote LLM service the cluster can reach.

None of these were performed for `eos-3-agent-verification-2`. The `cluster.sh provision` script stages 30 SSM params from `/olympus/int/*` but these are the prod fleet's params — they may not include working LLM keys (or those keys may be scoped to the int env), or the keys may not survive the per-cluster SSM scoping.

### Implication for §2.4 acceptance

The acceptance gate is a `Feedback__c` row arriving in the new scratch org with `Source__c='olympus-gpt'`. The feedback round-trip requires:
1. ✅ User authenticates against the cluster (works after Finding #21 fix).
2. ❌ User chats with Athena (currently fails with `Local LLM failed to respond.`).
3. ❌ User submits feedback (cannot complete without 2).

If the gpt SPA submits Feedback__c directly via a separate path (not through Athena), §2.4 might still close. Worth checking before declaring §2.4 blocked outright — but the canonical path goes through Athena.

### Fix paths

1. **Cluster-time LLM provisioning** — `cluster.sh provision` should accept an `--llm-provider <openai|anthropic|local-ollama>` flag and either inject the right SSM params or embed Ollama in the image.
2. **Provider sanity check after Live** — after the `/health` 200 check, `cluster.sh` should also call `/v1/athena/health` (or a deeper smoke endpoint) and assert the response is not an LLM-failure shape. If it is, the cluster is functionally not ready and the operator should be told why.
3. **Documentation gap** — `RUNBOOK-FROM-THE-VOID.md` Phase 5b should include "before spawning the cluster, set these SSM params" with explicit list and validation.

### Severity assessment

This finding blocks complete §2.4 closure, but **the EOS-3 attestation's PRIMARY goal — proving the system rebuilds from GitHub end-to-end — is satisfied at the auth + routing layer**. The LLM-provider gap is a configuration/operational concern that has nothing to do with whether the source-tree-to-running-system path works. The next EOS cycle should close this.

### Update 2026-06-11T20:53Z — root cause located

The attesting agent's curl was sending `{prompt:"ping"}` — missing the `agentId: 'athena'` field that the gpt SPA always includes (see `iris/reactforce/olympus-grid-ai/src/views/ChatTester.tsx:60-63`). Without `agentId`, Athena's router falls through to a default-agent code path that selects the Ollama (Local LLM) provider, which is genuinely not configured on the cluster — hence the `Local LLM failed to respond.` error. With the correct body `{prompt:"ping",agentId:"athena"}` curled against the freshly-spawned `eos-agent-verification-3` cluster (image `git-17553100`), Athena returned a perfect SSE stream from `gpt-4o-2024-08-06`:

> "Hello! I'm Athena, your guide on the TurtleShell.ai platform, built by CloudPremise LLC in Denver, Colorado. …"

48 completion tokens, finish_reason: stop. **Auth chain + provider routing + paid-LLM call all work end-to-end.**

The finding stays open at **medium** severity because the default-no-agentId path's silent fall-through to an unconfigured Ollama is still a footgun. The runbook recommendation now narrows to: either (a) make `agentId` required at the Athena `/chat` endpoint with a 400 if missing, or (b) ensure the default-agent path picks a configured provider (the same one `agentId: 'athena'` selects). The runtime gap doesn't block any production surface — every SPA client (ChatTester, ChatGPT, omens, turtleshell-*) sets `agentId` — but a runbook reviewer or curl-based health check WILL hit the misleading error.

---

## Finding #23 — CDK ALB name exceeds 32-char AWS limit when cluster name > 24 chars

**Severity:** high (blocks all cluster spawns with names ≥25 chars — including any name like `eos-3-agent-verification-N` for N>0)
**Compliance:** `SOC2:CC7.1` `SOC2:CC7.2` `SOC2:CC8.1` `ISO27001:A.5.10` `ISO27001:A.8.16` `ISO27001:A.12.1.2`
**Where:** `zeus/cdk/lib/cluster-stack.ts:294` (`loadBalancerName: \`olympus-${envConfig.envName}\``) + `olympus-grid/force-app/applications/default/classes/ApiRouteClusters.cls:29` (`NAME_PATTERN = ^[a-z][a-z0-9-]{1,30}[a-z0-9]$`)

During EOS-3 attestation, after the Steward created a second cluster row named `eos-3-agent-verification-2` (26 chars), `cluster.sh provision` failed CDK synthesis with:

```
UnscopedValidationError: Validation failed with the following errors:
  [olympus-eos-3-agent-verification-2-cluster/Alb] Load balancer name: "olympus-eos-3-agent-verification-2" can have a maximum of 32 characters.
```

The ALB name is constructed as `olympus-<envName>` (8 + envName chars). AWS caps ALB names at 32 chars, so envName must be ≤ 24 chars. The Apex cluster-name validation regex allows envName up to 32 chars (`{1,30}` between leading + trailing letters/digits) — 8 chars too generous. The script also performs no pre-CDK length check; the failure surfaces only after the operator has waited for SSM staging.

### Fix (proposed and applied during attestation)

Applied locally + verified working on `eos-3-agent-verification-2`:

```typescript
// zeus/cdk/lib/cluster-stack.ts
import * as crypto from 'node:crypto';

function buildAlbName(envName: string): string {
  const prefixed = `olympus-${envName}`;
  if (prefixed.length <= 32) return prefixed;
  const hash = crypto.createHash('sha256').update(prefixed).digest('hex').substring(0, 4);
  return prefixed.substring(0, 27) + '-' + hash; // 27 + 1 + 4 = 32
}
```

And replace the ALB construction's `loadBalancerName: \`olympus-${envConfig.envName}\`,` with `loadBalancerName: buildAlbName(envConfig.envName),`.

Companion changes to ship together:
- **Apex `ApiRouteClusters.cls`**: tighten validation to ≤ 24 chars envName so the constraint is enforced at row-creation time, with a clear error to the user.
- **`zeus/scripts/cluster.sh`**: add a pre-CDK length check that fails fast with the same error message — defensive layer for orgs that bypass the Apex validation.

Documentation: `RUNBOOK-FROM-THE-VOID.md` Phase 5b should note the 24-char limit on cluster names + the rationale (AWS ALB constraint + `olympus-` prefix).

PR being prepared.

---

## Finding #22 — `cluster.sh provision` and parent CDK deploy compete for the same `cdk.out` directory

**Severity:** high (any concurrent execution silently fails the spawning side)
**Compliance:** `SOC2:CC7.1` `SOC2:CC7.2` `ISO27001:A.8.16` `ISO27001:A.12.1.2`
**Where:** `zeus/scripts/cluster.sh` and the parent CDK deploy workflow both invoke `cdk` with no `--output` override, so both processes try to read/write `zeus/cdk/cdk.out/`.

During the EOS-3 attestation, after the Steward triggered the parent CDK deploy (which builds + pushes Pantheon, then runs CDK), the attesting agent fired `cluster.sh provision` against the new Cluster__c row while the parent deploy was still in its CDK-deploy phase. cluster.sh failed at CDK phase 1 with:

```
Other CLIs (PID=4786) are currently reading from cdk.out. Invoke the CLI in sequence, or use '--output' to synth into different directories.
[cluster.sh] CDK phase 1 failed (exit 1)
```

PID 4786 was the parent's CDK process holding the lock. cluster.sh's CDK invocation collided and aborted. SF `Cluster__c.Status__c` transitioned `Provisioning` → `Failed`.

This is **concurrent execution unsafety**: two legitimate, simultaneously-needed CDK operations (the canonical fleet redeploy and an ad-hoc cluster spawn) cannot run in parallel because they share the synth output directory. A future cycle that triggers more parallel ops will hit this regularly.

### Fix (proposed)

1. **Quick fix (one-line in `cluster.sh`)**: pass `--output zeus/cdk/cdk.out.cluster-${CLUSTER_NAME}` to every `cdk` invocation. Per-cluster output directory eliminates the shared-resource contention.
2. **Symmetric fix in the parent CDK deploy workflow**: have it use `--output cdk.out.parent-deploy`. Then the only collision would be two parent deploys running concurrently, which is itself a separate operational concern.
3. **Detect and bail explicitly**: cluster.sh can pre-check for `cdk.out/.lock` or run a `lsof zeus/cdk/cdk.out/` before invoking CDK; if held, print a clear error like "another CDK invocation is in progress — wait for it to finish (estimated remaining time: …)" and exit 7 with a known code so orchestration can retry.

For this attestation, the retry-after-parent-completes pattern worked. But that workaround assumes the operator knows the contention can happen.

---

## Finding #21 — Hermes `/v1/grid/master` proxy missing `unmanaged` namespace sentinel handling (ROOT CAUSE of #20)

**Severity:** blocker (single-line bug that breaks every dev-key flow on unmanaged-namespace scratch orgs)
**Compliance:** `SOC2:CC7.2` `SOC2:CC8.1` `ISO27001:A.8.16` `ISO27001:A.12.1.2` `PCI:Req6.3.2`
**Where:** `hermes/api/src/server.ts:549`
**Discovered via:** EOS-3 attestation root-cause investigation (2026-06-11)

The Hermes `/v1/grid/master/{*path}` proxy handler builds the upstream Salesforce REST URL like this (lines 547–553):

```typescript
const ns = process.env.OLYMPUS_GRID_NAMESPACE;
const nsPrefix = ns ? `${ns}/` : '';
...
const url = `https://${base}/services/apexrest/${nsPrefix}v1${ogPath}${queryString}`;
```

The cluster's `OLYMPUS_GRID_NAMESPACE` env var is set to the string `"unmanaged"` by `cluster.sh provision` (per the cluster-provision log: `/olympus/eos-3-agent-verification/OLYMPUS_GRID_NAMESPACE ← unmanaged`). This sentinel value means "the scratch org has no namespace prefix" — Apex routes are served under `/services/apexrest/v1/...` directly, not under `/services/apexrest/unmanaged/v1/...`.

The current `nsPrefix` calculation does not honor the sentinel: it treats `"unmanaged"` like any other truthy namespace and produces `unmanaged/`. The resulting URL — `/services/apexrest/unmanaged/v1/internal/identity/key-resolve` — is unreachable. Salesforce returns HTTP 500 with `"This URL could not be resolved to a handler"`. The Ares apiKeyMiddleware translates that to `reason: 'resolver_500'`.

### The fix already exists in a sibling file

`hermes/api/src/util/grid-master.ts:75` has the correct logic:

```typescript
// `'unmanaged'` is the sentinel ApiRouteClusters + cluster.sh stamp on scratch
// orgs that have no namespace prefix. SF Apex treats it as "no prefix"; Hermes
// must match by producing an empty string rather than literal "unmanaged/" in
// the URL (which 500s as "URL could not be resolved to a handler").
const ns = process.env.OLYMPUS_GRID_NAMESPACE;
const nsPrefix = ns && ns !== "unmanaged" ? `${ns}/` : "";
```

**The author of `grid-master.ts` knew about this sentinel, documented the exact failure mode (`'which 500s as "URL could not be resolved to a handler"'`), and implemented the correct handling — but only in the `buildApexrestUrl` helper. The `/v1/grid/master/{*path}` proxy handler in `server.ts` was not updated.** This is a partial fix that never propagated.

### Smoking-gun reproduction (attesting agent, 2026-06-11)

Direct call to the SF resolver via the **correct** path:
```
$ curl -X POST -H "x-service-name: ares" \
       -d '{"key":"og_live_3109719b8c0bcc89e213cecc6c947da6"}' \
       https://computing-fun-8671.scratch.my.site.com/portal/services/apexrest/v1/internal/identity/key-resolve
{"statusCode":201,"result":{"valid":true,"sub":"5691d453-...","accessToken":"eyJ0eXA...",...}}    # HTTP 201
```

Direct call via the **wrong** path Hermes is building:
```
$ curl -X POST -H "x-service-name: ares" \
       -d '{"key":"og_live_3109719b8c0bcc89e213cecc6c947da6"}' \
       https://computing-fun-8671.scratch.my.site.com/portal/services/apexrest/unmanaged/v1/internal/identity/key-resolve
"This URL could not be resolved to a handler"    # HTTP 500
```

Identical bodies, identical headers, different paths. The single difference between success and failure is the `unmanaged/` segment that the buggy line inserts.

Resolver test suite also passes 8/8 — see Finding #20. The Apex code is correct; the delivery path is broken.

### Fix (proposed)

One-line change in `hermes/api/src/server.ts:549`:

```diff
- const nsPrefix = ns ? `${ns}/` : '';
+ const nsPrefix = ns && ns !== 'unmanaged' ? `${ns}/` : '';
```

Better: extract a shared helper or reuse `buildApexrestUrl` from `grid-master.ts` (which already has the right logic AND the canonical comment) so the same sentinel handling is enforced in both places. Extract a `nsPrefix()` utility called by both call sites.

### Why EOS-3 §2.4 cannot close until this ships

Every `x-og-key` request from olympus-gpt against the spawned cluster fails at this single line. The user cannot complete a chat with Athena, cannot reach Poseidon, cannot list their clusters via the gpt picker (the picker call also goes through this proxy). The §2.4 acceptance Feedback__c-row gate is reachable but only by routing around the dev-key path entirely.

For full EOS-3 §2.x closure, this MUST ship before the cycle moves to `05_verifying/`.

---

## Finding #19 — gpt signup picker labels the scratch entry with a stale, hardcoded org URL

**Severity:** medium (cosmetic but misleads the operator into thinking calls will hit a dead org)
**Compliance:** `SOC2:CC2.1` `ISO27001:A.5.10`
**Where:** `iris/reactforce/olympus-grid-ai/src/lib/nodes.ts:51` — `SCRATCH_DEFAULT.identityUrl = 'https://innovation-app-8526.scratch.my.site.com/portal/services/apexrest'` (literal string from a *previous* scratch org). And the same string baked into the published bundle `olympus-grid/force-app/ui/portal/default/staticresources/olympus_gpt/static/js/main.bundle.dev.uqoj.js`.

Steward observation during EOS-3 (2026-06-11):
> "the gpt application is pointing at the wrong scratch org. this is apparently hard coded? this is in iris/reactforce/olympus-gpt-ai and its looking for innovation-app-8526 instead of the correct scratch org… on the gpt sign up page i need to choose [server] (production or scratch org) and the label says innovation on the scratch org."

The signup page's server picker renders the `name` + `identityUrl` from `SCRATCH_DEFAULT` directly. Because both are static module-level constants, every operator sees the URL of *whichever scratch org happened to be active when the bundle was last built*. The Steward built this bundle on 2026-06-11 08:39 when `innovation-app-8526` was active (pre-EOS-3 dev org). After `build.sh` destroyed `innovation-app-8526` and created `computing-fun-8671`, the bundle still shows the old URL until republished.

The *functional* path is corrected at runtime: `autoDeriveNode()` checks `window.location.host` and, when it matches `.scratch.my.site.com`, calls `withDerivedScratchUrl()` to rewrite `identityUrl` to `${window.location.origin}/portal/services/apexrest`. So actual API calls still go to the current scratch. But the **picker label** never updates — and an operator reading "Scratch Dev — innovation-app-8526" reasonably concludes the system is broken.

Also: `withDerivedScratchUrl()` overrides `identityUrl` only. It does NOT override `fleetUrl`. The static `fleetUrl: 'https://athena-303.templeathena.ai'` remains until the user explicitly picks a cluster from the registry (per `lib/clusters.ts`, which then sets `og_api_base` localStorage). For §2.4 acceptance, the user must select the spawned `eos-3-agent-verification` cluster from the picker AFTER logging in — otherwise the gpt app calls the stale fleetUrl.

### Fix (proposed)

1. **The same v2 plan the source code already comments on** (`nodes.ts:37-40`):
   > "v2 plan: inject scratch entry from olympus-grid/.agent/org-info.json at build time so the scratch URL tracks the current dev org automatically."
   This is the right fix. The bundle's build step should read `.agent/org-info.json` and emit `SCRATCH_DEFAULT.identityUrl = orgInfo.siteUrl + '/portal/services/apexrest'` (and `name = 'Scratch — ' + orgInfo.alias` or similar).

2. **Until v2 ships**, the picker should run `withDerivedScratchUrl()` at render-time (not just at "active node" resolution) so the DISPLAYED URL matches the URL the code will actually call. One-line change in the picker component.

3. **Also auto-derive fleetUrl from `.agent/org-info.json`'s cluster registry** at picker time, OR explicitly require the user to pick a cluster before exposing chat features (forcing the cluster-pick is arguably better UX — it makes the cluster selection visible instead of letting requests silently default to a stale fleet).

---

## Finding #18 — Iris portal session does not propagate to the gpt app; user lands on `/onboarding`

**Severity:** high
**Compliance:** `SOC2:CC6.1` `SOC2:CC6.2` `SOC2:CC2.1` `ISO27001:A.5.16` `ISO27001:A.5.17` `HIPAA:§164.308(a)(4)` `HIPAA:§164.312(a)(1)`
**Where:** session/cookie handling between `https://<scratch>.scratch.my.site.com/portal/*` (iris admin) and `https://<scratch>.scratch.my.site.com/portal/gpt/*` (olympus-gpt app under the same portal root).

Steward observation (2026-06-11):
> "it failed to login https://computing-fun-8671.scratch.my.site.com/portal/gpt/onboarding — i will start the gpt session in a new incognito session as it didn't make the hop successfully from the portal login to the gpt session"

After successfully signing into the iris admin portal as the super-user (`greg@cloudpremise.com`), navigating to the gpt surface served from the *same scratch-org portal site* (`/portal/gpt/...`) did not carry the existing session. The gpt SPA landed on `/onboarding` — its unauthenticated entry route — rather than recognizing the user as already signed in. The Steward worked around by opening a fresh incognito window and starting the gpt session there directly.

This is a session-isolation failure between two surfaces that share:
- The same hostname (`computing-fun-8671.scratch.my.site.com`)
- The same Salesforce Site
- The same scratch org's Identity__c / portal-user table
- Almost the same path prefix (`/portal/*` for iris admin vs `/portal/gpt/*` for gpt)

Per the project's documented session model (per CLAUDE.md § TurtleShell User Lifecycle / § Ares Cookie-to-Header Middleware), the canonical login cookie is `__Host-og_access` (or `og_access` on localhost) which is read by Ares and translated to `x-user-identity`. The gpt app should be reading the same cookie and recognizing the same JWT. It is not — or the cookie's Path attribute is too narrow (e.g., `/portal/` only, not `/portal/gpt/`), or the gpt app's session-detection logic is checking a different cookie name, or the SF Site is setting separate cookies per app path.

This is a **§2.4 acceptance impediment** — the gpt feedback round-trip must close *as the signed-in user* in the new scratch org. The incognito-and-sign-in-from-scratch workaround does NOT satisfy §2.9 (Repeatability) without intervention: an external human following the runbook will hit this exactly as Gregory did and have to figure out the workaround.

### Fix (proposed)

1. **Diagnose the cookie scope.** Inspect both surfaces after login and confirm: cookie name(s) set, Path attribute, Domain attribute, SameSite, Secure. The discrepancy is in one of those four.
2. **Make the gpt SPA's "am I logged in?" check identical to iris admin's.** Both should read the same canonical cookie/JWT. If they read different things today (e.g., gpt expects `og_access` while iris admin issued `__Host-og_access` and the migration is incomplete), unify.
3. **Cross-app navigation should be tested in CI.** Add an end-to-end test: log in to `/portal/` as super-user, immediately navigate to `/portal/gpt/`, assert the gpt SPA does NOT route to `/onboarding`. This is exactly the regression Gregory just caught manually.

### Workaround in use during this attestation

The Steward opened a fresh incognito window and started the gpt session directly at the gpt entry URL with an explicit login. The §2.4 round-trip continues from there. The workaround is documented but is NOT an acceptable §2.9 (Repeatability) artifact — the runbook must either fix this or call out the workaround explicitly.

---

## Finding #17 — PortalSiteUrlRewriter manual click is the keystone — without it, NOTHING routes

**Severity:** blocker (full-system routing depends on it; deploy reports success without it)
**Compliance:** `SOC2:CC2.1` `SOC2:CC7.1` `SOC2:CC8.1` `SOC2:CC8.2` `ISO27001:A.5.1` `ISO27001:A.8.16` `ISO27001:A.12.1.2` `HIPAA:§164.308(a)(1)(ii)(D)` `HIPAA:§164.312(b)` `PCI:Req6.3.2` `PCI:Req10.7`
**Where:** Salesforce Setup → Sites → [your Site] → Edit → **URL Rewriter Class** = `PortalSiteUrlRewriter`. Not API-accessible. Not auto-set by `loadDevEnterpriseScratchOrg.sh`. Not surfaced by the Salesforce Setup → Home → Connect onboarding (unlike Finding #12's verified email domain).

Steward's verbatim observation (2026-06-11), elevating this above Finding #8's bundled treatment:

> "i had to manually set the PortalSiteUrlRewriter to the site url rewriter. this is not listed in the olympus-grid setup and probably should, but we can worry about this later. this is actually like the dyke in the damn... without this one class the entire system falls apart since nothing can route correctly"

This is materially the single highest-impact manual step in the entire from-the-void recipe. Without it set:
- The portal site has no URL rewriting → every Iris-managed route 404s or routes to the raw Visualforce/Force.com URL.
- The cosmos-logos handshake URLs that surfaces use to authenticate against the spawning org never resolve → no surface (omens, gpt, turtleshell-*) can complete sign-in.
- The §2.x acceptance criteria from §2.3 through §2.8 all silently fail because the surfaces can't reach the routing layer that maps their requests to Apex REST.

Yet the deploy script runs to completion, the build's post-build error scan says "✅ No errors found in build log" (Finding #10's lying scanner), and the iris admin Clusters page appears to work — because the iris admin UI is loaded via a different path that does NOT depend on PortalSiteUrlRewriter. So the operator believes everything is up, until a surface attempts a routed request and silently breaks.

This pattern — *one manual click in Setup → entire downstream system unreachable, with no signal at deploy time* — is exactly the failure mode SOC-2 CC7.1 (Detect) and ISO 27001 A.8.16 (Monitoring) exist to surface. It is not surfaced.

### Fix (urgency: ship before any further EOS-cycle attestation)

Three layers, in priority order:

1. **Automate it.** PortalSiteUrlRewriter is configured on the `Site` SObject via the `UrlRewriterClass` field. Per the script's REMINDER block, this is "not API-accessible" — but this should be re-verified. Even if the Metadata API path is closed, Tooling API and the SOAP API may expose it. If any path works, automate at `loadDevEnterpriseScratchOrg.sh` step ~10 (preparePortalSite.sh expansion).

2. **If truly UI-only**, the post-deploy script must:
   - Open the Salesforce Site Setup page automatically (via `sf org open --path` to a deep link)
   - Print bold red instructions to the operator's console as the final line of the deploy
   - Exit non-zero if `Site.UrlRewriterClass` is empty (a SOQL check would catch this without Setup-UI scraping)

3. **Smoke-test it.** Add to `build.sh` post-deploy: an HTTPS GET to a known portal-routed URL on the new scratch org, asserting it returns the expected route response and NOT a 404. A 30-second test that catches "dyke in the dam removed" in CI.

### Cross-reference to existing findings

- Finding #8 lists this as item 1 of 4 manual configs — it should be *the* finding, with #8 demoted to "the other three."
- Finding #10's lying error scanner is what made this invisible at deploy time. Fixing #10 is necessary but not sufficient — without #10 fixed, even the "automated check" recommended above would never reach the operator if it printed an error.

### Direct empirical evidence (2026-06-11T~18:08Z)

After the Steward set `PortalSiteUrlRewriter` on the scratch org's Site, the URL `https://computing-fun-8671.scratch.my.site.com/portal/gpt` immediately became reachable and rendered the gpt front end. This URL had not been functional before the click. There is no other change to attribute the routing-recovery to. This is the *direct* empirical proof that the single class assignment is the on/off switch for portal-routed surface availability.

For SOC-2 CC8.2 (Changes to the System): one config field flips the entire downstream surface set between "appears broken" and "works." That is by definition a critical control point that demands automation, monitoring, and rollback semantics. Today it has none.

---

## Finding #16 — `cluster.sh` does not clear `ErrorMessage__c` when restarting a Failed cluster

**Severity:** medium (UX-driven attestation false-alarm)
**Compliance:** `SOC2:CC2.1` `SOC2:CC7.2` `ISO27001:A.8.16` `HIPAA:§164.308(a)(1)(ii)(D)`
**Where:** `zeus/scripts/cluster.sh` (the Failed→Provisioning transition).

When the operator re-runs `cluster.sh provision` against a `Cluster__c` row whose `Status__c='Failed'`, the script correctly transitions `Status__c` back to `Provisioning` and resumes work. It does NOT clear `ErrorMessage__c`. The iris admin Clusters UI reads both fields and shows the (now stale) error message on a row that is, by status, actively provisioning.

Steward's verbatim observation (2026-06-11):
> "note... it still says error on the ui"

Confirmed via SOQL at attestation time:
```json
{
  "Status__c": "Provisioning",
  "ErrorMessage__c": "CDK phase 1 failed (exit 1)",
  "LastModifiedDate": "2026-06-11T17:50:47Z"
}
```

This is a SOC-2 CC2.1 (Communication) failure: the system communicates "this thing failed (error message visible)" while *actually* doing useful work. An operator following the UI in good faith would assume the provision is stuck and intervene unnecessarily — potentially canceling a working provision midflight.

**Fix:** In `cluster.sh`, the Failed→Provisioning transition must clear `ErrorMessage__c` to null in the same SF update. One additional `ErrorMessage__c=null` field in the existing `sf data update record` call. A 1-line change. **The same fix must apply at the Provisioning→Live transition** — see "Update" below.

Symmetric fix for the iris admin UI: when rendering a row in `Status__c='Provisioning'` or `Status__c='Live'`, ignore `ErrorMessage__c` (or render it as "previous error, retrying"). Defensive at the UI layer in case the server-side fix regresses.

### Update (after cluster reached Live, 2026-06-11T18:05:29Z)

The cluster transitioned all the way to `Status__c='Live'` with `EndpointUrl__c='https://api-eos-3-agent-verification.turtleshell.ai'` populated and the AWS infrastructure responding 200 on /health. `ErrorMessage__c` **still reads "CDK phase 1 failed (exit 1)"** — the stale error from the first attempt is now displayed on a live, healthy cluster.

This is materially worse than the Provisioning-with-stale-error case originally documented. SOC-2 CC2.1 is now actively misleading the operator into thinking a working cluster is broken. The Provisioning→Live transition in `cluster.sh` (the final SF update where Status='Live' and EndpointUrl=... is set) must also clear `ErrorMessage__c`. Same one-line change, applied to a second code site.

---

## Finding #15 — `zeus/scripts/cluster.sh provision` fails because `zeus/cdk/node_modules` is not pre-installed

**Severity:** blocker (gates §2.2 cluster spawn end-to-end)
**Compliance:** `SOC2:CC2.1` `SOC2:CC8.1` `ISO27001:A.5.10` `ISO27001:A.12.1.2`
**Where:** `zeus/scripts/cluster.sh`, `zeus/cdk/bin/app.ts`, and the broader `build.sh` / `loadDevEnterpriseScratchOrg.sh` chain that does not install CDK deps.

During EOS-3 Phase 2 the operator (Steward) ran the script that Finding #14 says must be run manually:

```bash
bash ~/dev/repos/olympus-616/zeus/scripts/cluster.sh provision \
  --instance-url https://computing-fun-8671.scratch.my.salesforce.com \
  --site-url   computing-fun-8671.scratch.my.site.com/portal \
  --cluster-id a04Ec00000DFrcPIAT
```

The script:
1. Authenticated to AWS (✓), to the spawning SF org (✓)
2. Set `Cluster__c.Status__c = Provisioning` (✓)
3. Staged 30 SSM parameters under `/olympus/eos-3-agent-verification/*` (✓)
4. Invoked `npx ts-node bin/app.ts` for CDK phase 1 → **FAILED**

The TypeScript compile error chain reads:

```
TSError: Unable to compile TypeScript:
bin/app.ts(19,22): error TS2307: Cannot find module 'aws-cdk-lib' or its corresponding type declarations.
bin/app.ts(35,50): error TS2580: Cannot find name 'process'. Do you need to install type definitions for node?
… (18 more diagnostics, all stemming from missing node_modules and @types/node)
```

Confirmed root cause: `zeus/cdk/node_modules/` did not exist on the host. `cluster.sh` invokes `npx ts-node` against `bin/app.ts` without verifying or installing the CDK directory's dependencies first.

`Cluster__c.Status__c` transitioned to **`Failed`** as a result.

Fix is one of:

1. **In `cluster.sh`:** detect `[ ! -d zeus/cdk/node_modules ]` before phase 1 and run `(cd zeus/cdk && npm ci)`. Smallest, lowest-risk change. Adds ~2 seconds the first time, zero seconds after.
2. **In `build.sh`:** add `zeus/cdk` to the list of directories that get `npm ci`'d alongside root / api / ui. Aligns with the rest of the build's dependency-install pattern.
3. **In `loadDevEnterpriseScratchOrg.sh`:** call `cluster.sh` self-test (or just run `npm ci` in zeus/cdk) before declaring scratch-org load complete. Closes the gap at the cycle level rather than the per-invocation level.

**Combined recommendation:** ship (1) in `cluster.sh` immediately (it's a 3-line change), and add (2) so the dev-environment first-time-setup gets CDK deps installed before they're needed. The redundancy is acceptable; it's a strict-mode `set -e` failure today and a 2-second op tomorrow.

The npm install of zeus/cdk reported 4 additional vulnerabilities (3 moderate, 1 high). These are now part of Finding #4's running tally (10 → 14 total vulnerabilities across the in-scope npm trees).

---

## Finding #14 — "Spawn a cluster" in iris admin creates `Cluster__c` row but does NOT actually provision AWS

**Severity:** high
**Compliance:** `SOC2:CC2.1` `SOC2:CC8.1` `ISO27001:A.5.10` `ISO27001:A.12.1.2` `HIPAA:§164.308(a)(1)(ii)(D)`
**Where:** iris admin → Clusters → SpawnCluster modal (`iris/reactforce/portal/src/plugins/admin/src/components/Modals/Clusters/SpawnCluster.tsx`), `ApiRouteClusters.handleSpawn`, and the unbuilt link to `zeus/scripts/cluster.sh provision`.

The iris admin "Spawn a cluster" button creates a `Cluster__c` row with `Status__c='Pending'`. It does NOT trigger AWS Fargate provisioning. To complete the cluster spawn, the operator must manually run (with operator-supplied SF instance + site URLs and the Cluster__c Id):

```bash
bash ~/dev/repos/olympus-616/zeus/scripts/cluster.sh provision \
  --instance-url https://<scratch>.scratch.my.salesforce.com \
  --site-url <scratch>.scratch.my.site.com/portal \
  --cluster-id <Cluster__c.Id>
```

This violates EOS-2 §1 + §3 ("zero touch, full visibility… admin never leaves the managed package surface to complete the loop") and EOS-3 §2.2 ("spawn an AWS Pantheon cluster from inside the iris admin UI"). The "Spawn" button currently sets a row to `Pending` and lies about what it accomplished — a SOC-2 CC2.1 communication failure.

Two possible reasons this gap exists, both finding-worthy:

1. **Intentional sovereignty design.** EOS-2 §3 NFR is "No long-lived AWS access keys at rest inside Salesforce." If a Salesforce row alone cannot have AWS credentials, *something* needs to run with AWS credentials to actually provision. Today that something is the operator running `cluster.sh` from their laptop. Long-term solutions include: a poller daemon on the customer's AWS account that watches for Pending rows and provisions them; or a Lambda triggered by EventBridge from the SF Outbound Message. Neither exists today.
2. **Unfinished EOS-2 work.** §2.1 of EOS-2 closed on athena-717 reachability but the auto-provisioning daemon was a §13 deferred gap that hasn't been picked up in a subsequent cycle.

Steward's verbatim instruction (2026-06-11):
> "i used eos-3-agent-verification as the cluster name running it on CloudPremise managed aws. here is the script to run. bash ~/dev/repos/olympus-616/zeus/scripts/cluster.sh provision … let me know how it goes"

That instruction is itself the finding — the cycle's attesting agent could not complete §2.2 acceptance without the Steward telling it which script to run with what arguments. EOS-3 §2.9 (Repeatability — "any human holding the source repeats §2.1 → §2.8 on a fresh machine then the chain completes without Steward intervention") fails this check.

**Fix paths (proposed, ordered by completeness):**

1. **Document the two-step pattern in the UI.** The SpawnCluster modal's success message should read "Cluster row created (Pending). To provision the AWS infrastructure, run `bash zeus/scripts/cluster.sh provision --cluster-id <Id> --instance-url <url> --site-url <url>` from your operator workstation. The cluster will transition to Live when provisioning completes." This is the smallest possible fix and turns the deception into honesty.

2. **Provide a copy-paste command in the modal.** Same idea as (1), but the modal renders the exact command with placeholders substituted. One copy-click.

3. **Ship the auto-provisioner.** A daemon (Lambda + EventBridge, or a long-poll job inside the spawning customer's own AWS account) reads Pending rows and provisions them. Closes the EOS-2 NFR claim cleanly. This is the **right** answer; (1) and (2) are bridges to it.

---

## Finding #12 — Verified email domain must be manually configured in Setup → Home → Connect → Set Up

**Severity:** high (gates the email-bearing surfaces of the platform)
**Compliance:** `SOC2:CC2.1` `SOC2:CC8.1` `ISO27001:A.5.1` `ISO27001:A.12.1.2` `HIPAA:§164.308(a)(8)` `PCI:Req6.3.2`
**Where:** Salesforce Setup → Home → Connect → Set Up (UI-only path; not API-accessible without further mechanism)

After `build.sh` completed and the Steward opened the scratch org for the first time during the EOS-3 attestation, the Salesforce Setup → Home → Connect surface displayed an explicit instruction to create a verified email domain record. This is required for any platform surface that sends outbound email (Web2Case, Hermes messaging, account-verification flows, the cosmos-logos handshake email channels, etc.).

The instruction is reached via clicks: Home → Connect → Set Up. There is no analog in `loadDevEnterpriseScratchOrg.sh` or `build.sh` — the script does not create the domain record, does not assert its presence, and does not surface to the operator that it needs to be done.

This is a **distinct** issue from Finding #8's enumerated manual configurations. The script's own REMINDER block lists four (PortalSiteUrlRewriter, logout URL, guest user email, Azure redirect URL); the verified email domain is a *fifth* manual click that the script does not call out at all. It is therefore a stronger reproducibility gap: the script's own author did not record it.

Steward's verbatim observation (2026-06-11):
> "i need to create a verified email domain record. i know this because i opened the scratch org and then i clicked Set Up and there was an instruction to do this (Home --> Connect --> Set Up)"

**Fix (proposed):**
1. Add an explicit line to `loadDevEnterpriseScratchOrg.sh`'s REMINDER block calling out "Setup → Home → Connect → Set Up → Verified Email Domain — required for outbound email surfaces."
2. Investigate whether Email Domain verification is now exposed via the Salesforce Metadata API or Tooling API. If yes, automate. If no, this finding becomes part of the documented manual-step set (carry forward to EOS-AWS-VOID's runbook for parity).
3. Update `RUNBOOK-FROM-THE-VOID.md` Phase 3's manual-configuration section to include this fifth click with exact navigation path.

---

## Finding #13 — Default sending email address is hardcoded to the iris portal user (research / configurability gap)

**Severity:** medium (product-correctness)
**Compliance:** `SOC2:CC6.1` `ISO27001:A.5.15` `ISO27001:A.5.16` `HIPAA:§164.308(a)(3)`
**Where:** TBD — research required. Likely in Apex (email-sending classes) and/or in iris portal config.

The Steward observed during EOS-3 that the customer's default sending email address appears to be derived from the iris portal user's email rather than configured per-tenant. This is currently functional but inflexible — a customer installing the Olympus-Grid managed package who wants outbound emails to come from `notifications@their-domain.com` (rather than from the user who happens to be administering the portal) has no clean configuration surface to make that change.

This is recorded as a research item *and* a configurability finding. The full research task (which goes into Phase B / EOS-4 input) is:

1. Locate the code path that determines `OrgWideEmailAddress` or the sender identity for outbound Hermes/Web2Case/account-verification mails.
2. Identify the configuration surface that should drive it (likely a Plugin__mdt field or a custom setting under the Olympus_Grid admin permset).
3. Specify the per-tenant override pattern and update the iris admin UI to expose it.

Steward's verbatim observation:
> "research item for later research - how does the customer set the default sending email address? right now i believe it is the email address of the iris portal user. this will need to be modified to be easily set elsewhere."

**Out of scope for EOS-3 closure** (this does not gate §2.x). Carries forward to EOS-4 §13.x deferred-gaps inheritance.

---

## Finding #11 — Launcher UI shows an unguarded "Launch" button regardless of cluster readiness

**Severity:** high (UX-driven attestation failure)
**Compliance:** `SOC2:CC2.1` `SOC2:CC7.1` `ISO27001:A.5.10` `ISO27001:A.8.6` `HIPAA:§164.308(a)(1)(ii)(D)`
**Where:** `olympus-616/ui/src/*` (the React control-plane UI served on port 616) + `olympus-616/api/src/*` (the `/api/gods` endpoint).

The dashboard at http://localhost:616 displays a prominent **Launch** button after the launcher boots. The button is enabled whether or not the cluster is actually ready to start — specifically, whether or not `olympus-grid/.agent/org-info.json` exists (which is how Hermes discovers the Salesforce backend; see Phase 4 of `RUNBOOK-FROM-THE-VOID.md`).

A user following the README — or an external human following `RUNBOOK-FROM-THE-VOID.md` — sees the button, presses it, and gets:
- 31 god terminals opening
- Most coming up "fine"
- Hermes pointed at a default (or stale) backend
- Athena half-working depending on local Ollama state
- A confusing state where the dashboard reports gods as "online" while no real workload can complete a request

Under SOC-2 CC2.1 (Communication of objectives) and CC7.1 (System Operations - Detection), the launcher is communicating an incorrect operational state to its user. Under ISO 27001 A.5.10 (Acceptable use of assets), the asset's affordances are inviting misuse.

Steward's verbatim observation (2026-06-11):
> "we launch the app, there is a big launch button... i feel like we should push it or we need to change the way this is presented. the launcher app was designed to sit atop the launching fleet."

**Fix (proposed):**
1. The `/api/gods` endpoint already enumerates every god and its endpoint state. Extend it with a top-level `cluster.ready: boolean` plus a list of `cluster.missing` strings — e.g., `[".env not present", ".agent/org-info.json missing — run capture-org-info.sh", "ollama not reachable", "OLYMPUS_GRID_NAMESPACE not set"]`.
2. The UI binds the Launch button's `disabled` state to `cluster.ready === false`, and renders the `cluster.missing` list above the button as actionable preflight messages. When `cluster.ready === true` the button enables with its current styling.
3. For the "press anyway" power-user path, the UI offers a smaller "Launch anyway (advanced)" link that surfaces a confirmation modal listing the missing checks. Confirms the user accepts the consequences.

The launcher's tagline ("sits atop the launching fleet") is the right design intent; this finding closes the gap between intent and current implementation.

This finding was identified by the Steward during the EOS-3 attestation when he asked "am i good to press the launch button" and the attesting agent had to explain *no, because…* — that conversation is *itself* evidence that the UI doesn't carry the readiness information into the user's hands. A reproducible system cannot rely on an attesting agent being available to explain when the big button is safe to press.

---

## Finding #10 — Deploy scripts swallow Apex compile errors and report success

**Severity:** high (and arguably blocker for SOC-2)
**Compliance:** `SOC2:CC7.2` `SOC2:CC7.3` `SOC2:CC8.1` `ISO27001:A.8.16` `ISO27001:A.12.1.2` `PCI:Req6.3.2` `PCI:Req10.7` `HIPAA:§164.308(a)(1)(ii)(D)` `HIPAA:§164.312(b)`
**Where:** `olympus-grid/scripts/bash/deploy/deploy_bpm.sh`, `deploy_proteus_objects.sh`, and likely siblings.

During EOS-3 Phase 2, the source-deploy phase of `loadDevEnterpriseScratchOrg.sh` produced three real Apex compile errors:

```
deploy_bpm.sh:
  Error (executeCompileFailure): Compilation failed at Line 15 column 5 with the error:
    Field does not exist: WorkingState__c on ProcessQueue__c
  Error (executeCompileFailure): Compilation failed at Line 20 column 22 with the error:
    Variable does not exist: ProcessQueue__c

deploy_proteus_objects.sh:
  Error (executeCompileFailure): Compilation failed at Line 4 column 5 with the error:
    Field does not exist: ObjectStorage__c on DynamicObjectType__c
```

Each script nonetheless printed `✅ [COMPLETE] ... deployed successfully.` and the parent `loadDevEnterpriseScratchOrg.sh` continued. The scratch org therefore lands in a state where certain Apex initialization scripts did not run, but the build *reports* success. SOC-2 monitoring (CC7.2) and ISO 27001 A.8.16 specifically require that monitoring activities detect anomalies — a build that returns 0 while failing to deploy code is exactly the anomaly these controls exist to surface.

Equally important for HIPAA `§164.312(b)` (Audit Controls) and PCI `Req 10.7` (audit log retention): the swallowed error is recorded in the log file but not surfaced to the caller, so any downstream alerting that triggers on "non-zero exit" never fires. Anyone who only watches exit codes will believe the deploy was clean.

**Fix:**
1. Every `sf apex run` and `sf project deploy` invocation in `deploy_*.sh` must check its exit code and propagate failures up to `loadDevEnterpriseScratchOrg.sh`, which must in turn fail the build.
2. The "✅ [COMPLETE]" success print is currently unconditional. Gate it on the exit code being 0.
3. Add a top-of-script `set -e` so any unguarded failure aborts. (Note: `set -e` may need careful handling around `|| true` patterns and `sf` calls that legitimately warn-but-succeed.)
4. The underlying Apex code references missing fields (`WorkingState__c`, `ProcessQueue__c` variable, `ObjectStorage__c`). Identify the schema drift between the Apex source and the SObject definitions in `force-app/`, and reconcile — either add the fields or update the Apex.

This finding is a candidate for **immediate** Phase B remediation. Until it ships, downstream attestations cannot trust that "deploy success" means anything.

### Update (after build.sh completed, 2026-06-11T17:11Z)

The severity of this finding is materially *worse* than originally documented. After all 13 deploy steps + the Apex test phase, `olympus-grid/build.sh` printed:

```
📋 [POST-BUILD] Scanning build log for errors, failures, or exceptions...
✅ No errors found in build log.
🏁 [BUILD SUCCESSFUL]
```

— in the same log that contains the three `Error (executeCompileFailure): Compilation failed at Line ...` entries from the BPM and Proteus deploys. The post-build error scanner has a regex or grep pattern that does not match the actual error strings the deploy scripts print.

This is *worse* than swallowing per-script: it's a build-level lie. A CI/CD pipeline that exits 0 on this output will deploy known-broken Apex to production. SOC-2 CC7.2 (detection of anomalies in system operations), HIPAA §164.308(a)(1)(ii)(D) (information system activity review), and PCI Req 10.7 (log retention requires the logs to be *meaningful*) are all materially undermined by a scanner that misses real errors in its own input.

**Additional fix (urgent):** Audit `olympus-grid/build.sh` for the post-build scan implementation. Whatever pattern it uses — likely a `grep -E ...` against the log file — must match the actual strings emitted by `sf apex run`, `sf project deploy`, and `executeCompileFailure`. The current pattern misses all three.

---

## Finding #9 — Scratch org definition has 4 invalid features

**Severity:** medium
**Compliance:** `SOC2:CC8.1` `ISO27001:A.12.1.2`
**Where:** `olympus-616/olympus-grid/orgs/dev-enterprise.json`

`sf org create scratch` reported during the EOS-3 Phase 2 run:

```
Warning: Scratch org definition validation issues in orgConfig:
  features.3:  Invalid input
  features.4:  Invalid input
  features.5:  Invalid input
  features.10: Invalid input
```

The org was created anyway (Salesforce skipped the unrecognized feature flags), but the warnings indicate the definition file references features that no longer exist or are spelled wrong. Whatever capability those features were meant to enable is silently absent from every scratch org created from this definition.

**Fix:** Open `orgs/dev-enterprise.json`, identify entries at indices 3, 4, 5, 10 of the `features` array, and reconcile against the [current Salesforce feature list](https://developer.salesforce.com/docs/atlas.en-us.sfdx_dev.meta/sfdx_dev/sfdx_dev_scratch_orgs_def_file_config_values.htm). Either correct each spelling/enable the right replacement feature, or remove the entry if no longer needed.

---

## Items that worked on first attempt (positive findings — record these too)

- `gh repo list olympus-616 --limit 200` and `gh repo list cosmos-logos --limit 200` returned correctly.
- After the SSH→HTTPS workaround, recursive submodule clone succeeded for all 38 submodules in olympus-616 plus all 5 working cosmos-logos repos. ~45 seconds total.
- `bash build.sh` completed in 3.0s after the `npm ci` cache was warm.
- `bash run.sh` brought API + UI online in 3s; idempotency guard at `run.sh:23` correctly prevents double-launch.
- `GET http://localhost:615/api/gods` returns a 17.9 KB JSON of 33 entries (1 self + 31 gods + 1 infrastructure = matches README claim of "31 services").
- Process tree at runtime: 1 concurrently → 2 npm → tsx watch + vite. Clean, expected.

### Phase 2 positive findings (Iris portal + Salesforce side)

- **Auto-provisioned super user** — after the scratch org loads and the DevHub user logs in, the Iris portal recognizes the DevHub user identity and **automatically provisions a portal super-user** with no manual step required. Steward observation (2026-06-11): *"this super user was created for me by the system which i didn't even ask for! i think a previous agent thought through it well."* This is a meaningful UX win — every external human following the runbook gets a usable portal super-user without any "go create a user" friction. Record as **expected and good behavior** in the runbook so external reviewers know to look for it (and so a future regression that removes it is flagged).
- **Email round-trip via the Verified Domain works** — once Finding #12's manual click (Setup → Home → Connect → verified email domain) is completed for the user's own domain (`cloudpremise.com` in this run), the system actually sends the welcome email and Gregory receives it from `Portal Site Guest User <greg@cloudpremise.com> via eazjz9l3aj7s.ec-gnsecmag.usa22s.bnc.sandbox.salesforce.com`. The sandbox BNC bounce-tracking host is correctly set; the From header carries the configured domain. This is **the verification that Finding #12's manual step actually closes the email loop end-to-end**, not just appears configured. A future cycle that automates Finding #12 should preserve this exact round-trip as the test that the automation worked.
- **DNS-bound sender identity is a configuration affordance (cf. Finding #13)** — Steward note: *"i had to set the dns to cloudpremise for emails... if i want acme.com it should work elsewhere we will test it once we get all the way to templeathena.ai."* The current behavior — sender domain follows whatever DNS the operator verifies — IS the intended configuration model. Finding #13 (default sending email config gap) is about exposing that as a customer-facing setting, not about replacing the DNS-binding mechanism, which works correctly.

## Pre-attestation items NOT yet exercised in this run

- **Ollama preflight** (lines 1700–1820 of alchemisthomer.sh). Not exercised because the launcher itself does not depend on Ollama — only the Athena god does, and gods are not spawned in this attestation. For full audit, perform a follow-up run that boots Athena and confirms it responds via Ollama-backed inference.
- **31-god live launch from the dashboard.** The launcher reports them as idle; an end-to-end attestation would click Launch in the UI and capture health-check responses from each god. This was intentionally deferred — gods spawn separate terminals + 31 long-running node processes, which is a heavier runtime claim than this build-and-control-plane attestation.
- **cosmos-logos repos** (turtleshell-web, turtleshell-offgrid, thoth, alpha, resolver2): cloned, but not built. Standing them up against the live local pantheon would be the next attestation milestone.
