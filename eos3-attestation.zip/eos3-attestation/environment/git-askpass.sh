#!/bin/bash
# GIT_ASKPASS helper for EOS-3 attestation.
# Returns the gh-issued GitHub token for any password prompt and "x-access-token" for username.
case "$1" in
  *[Uu]sername*) echo "x-access-token" ;;
  *[Pp]assword*) gh auth token ;;
esac
