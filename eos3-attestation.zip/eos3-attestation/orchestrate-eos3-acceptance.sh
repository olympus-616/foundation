#!/bin/bash
# EOS-3 acceptance orchestration — run autonomously after Gregory leaves
# Steps:
#   1. Wait for new Pantheon tag in ECR (parent CDK deploy publishes it)
#   2. Run cluster.sh provision against a04Ec00000DG1jpIAD
#   3. Wait for Status__c='Live'
#   4. Curl Athena with the dev key — verify HTTP 200
#   5. Record artifact at /Users/gregory/dev/repos/eos3-attestation/artifacts/athena-§2.4-result.json

LOG=/Users/gregory/dev/repos/eos3-attestation/logs/orchestrate.log
exec > >(tee -a "$LOG") 2>&1
echo ""
echo "════════════════════════════════════════════════════════════════════"
echo "EOS-3 acceptance orchestration starting at $(date -u +%Y-%m-%dT%H:%M:%SZ)"
echo "════════════════════════════════════════════════════════════════════"

NEW_CLUSTER_ID=${NEW_CLUSTER_ID:?must export NEW_CLUSTER_ID}
DEV_KEY=og_live_3109719b8c0bcc89e213cecc6c947da6
BASELINE_TAG=${BASELINE_TAG:-git-acc9074a}
SF_INSTANCE=https://computing-fun-8671.scratch.my.salesforce.com
SF_SITE=computing-fun-8671.scratch.my.site.com/portal

# === STEP 1: Wait for new Pantheon image ===
echo ""
echo "STEP 1: Waiting for new Pantheon tag in ECR (baseline: $BASELINE_TAG)..."
START=$(date +%s)
while true; do
  CURRENT=$(aws ecr describe-images --repository-name olympus-616/pantheon --region us-east-1 \
    --query 'reverse(sort_by(imageDetails,&imagePushedAt))[0].imageTags[0]' --output text 2>/dev/null)
  if [ -n "$CURRENT" ] && [ "$CURRENT" != "None" ] && [ "$CURRENT" != "$BASELINE_TAG" ]; then
    echo "  ✓ New tag detected: $CURRENT (after $(($(date +%s) - START))s)"
    NEW_TAG=$CURRENT
    break
  fi
  # Bail out if parent deploy failed
  PARENT_STATUS=$(gh run view "${PARENT_RUN_ID:-27373997672}" --repo olympus-616/olympus-616 --json status,conclusion 2>/dev/null | jq -r '"\(.status):\(.conclusion)"')
  if [[ "$PARENT_STATUS" == "completed:failure" ]] || [[ "$PARENT_STATUS" == "completed:cancelled" ]]; then
    echo "  ✗ Parent CDK deploy failed: $PARENT_STATUS — bailing"
    echo "BAIL_REASON=parent_deploy_failed PARENT_STATUS=$PARENT_STATUS" > /Users/gregory/dev/repos/eos3-attestation/artifacts/orchestrate-bail.json
    exit 10
  fi
  sleep 60
done

# === STEP 2: cluster.sh provision ===
echo ""
echo "STEP 2: cluster.sh provision against $NEW_CLUSTER_ID..."
bash ~/dev/repos/olympus-616/zeus/scripts/cluster.sh provision \
  --instance-url "$SF_INSTANCE" \
  --site-url "$SF_SITE" \
  --cluster-id "$NEW_CLUSTER_ID" 2>&1 | tee /Users/gregory/dev/repos/eos3-attestation/logs/cluster-provision-acceptance.log
PROV_EXIT=${PIPESTATUS[0]}
echo "  cluster.sh exit=$PROV_EXIT"

# === STEP 3: Wait for Status=Live ===
echo ""
echo "STEP 3: Waiting for Cluster__c Status='Live'..."
START=$(date +%s)
while true; do
  STATUS=$(sf data query --target-org dev_enterprise --query "SELECT Status__c FROM Cluster__c WHERE Id = '$NEW_CLUSTER_ID'" --json 2>/dev/null | jq -r '.result.records[0].Status__c // ""')
  if [ "$STATUS" = "Live" ]; then
    echo "  ✓ Status=Live after $(($(date +%s) - START))s"
    break
  fi
  if [ "$STATUS" = "Failed" ] && [ $(($(date +%s) - START)) -gt 60 ]; then
    echo "  ✗ Status=Failed — bailing"
    echo "BAIL_REASON=cluster_failed" > /Users/gregory/dev/repos/eos3-attestation/artifacts/orchestrate-bail.json
    exit 11
  fi
  sleep 30
done

# === STEP 4: Athena curl ===
ROW_JSON=$(sf data query --target-org dev_enterprise --query "SELECT EndpointUrl__c, ClusterName__c FROM Cluster__c WHERE Id = '$NEW_CLUSTER_ID'" --json 2>/dev/null)
ENDPOINT=$(echo "$ROW_JSON" | jq -r '.result.records[0].EndpointUrl__c')
CLUSTER_NAME_OBSERVED=$(echo "$ROW_JSON" | jq -r '.result.records[0].ClusterName__c')
echo ""
echo "STEP 4: curl $ENDPOINT/v1/athena/chat with dev key"
echo "  (a few warmup curls in case Ollama / Athena haven't finished booting)"

for attempt in 1 2 3 4 5; do
  RESPONSE=$(curl -s -w "\n__HTTP %{http_code}__" -X POST \
    -H "x-og-key: $DEV_KEY" \
    -H "Content-Type: application/json" \
    -d '{"prompt":"ping","agentId":"athena"}' \
    --max-time 60 \
    "$ENDPOINT/v1/athena/chat")
  CODE=$(echo "$RESPONSE" | grep -oE "__HTTP [0-9]+__" | grep -oE "[0-9]+")
  echo "  attempt $attempt → HTTP $CODE"
  if [ "$CODE" = "200" ]; then
    echo "  ✓ §2.4 ACCEPTANCE: Athena returned 200"
    break
  fi
  sleep 20
done

# === Final artifact ===
cat > /Users/gregory/dev/repos/eos3-attestation/artifacts/athena-§2.4-result.json <<JSON
{
  "clusterId": "$NEW_CLUSTER_ID",
  "clusterName": "$CLUSTER_NAME_OBSERVED",
  "endpointUrl": "$ENDPOINT",
  "imageTag": "$NEW_TAG",
  "completedAt": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "athenaChatHttp": $CODE,
  "athenaChatResponse": $(echo "$RESPONSE" | sed 's/__HTTP.*__//' | jq -Rs .),
  "verdict": "$([ "$CODE" = "200" ] && echo "PASS" || echo "FAIL")"
}
JSON

echo ""
echo "════════════════════════════════════════════════════════════════════"
echo "Orchestration complete at $(date -u +%Y-%m-%dT%H:%M:%SZ)"
echo "Final HTTP: $CODE"
echo "Endpoint: $ENDPOINT"
echo "Image tag: $NEW_TAG"
echo "════════════════════════════════════════════════════════════════════"
