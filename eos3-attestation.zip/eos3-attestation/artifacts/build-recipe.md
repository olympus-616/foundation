# Build recipe extracted from olympus-616 README + CLAUDE.md

**Source files:** `olympus-616/README.md`, `olympus-616/CLAUDE.md`
**Captured at:** 2026-06-11T14:40:00Z

## Prerequisites (per README §Quick Start)

- Node.js 18+
- Git with submodule support
- (Optional) Claude Code "or similar AI terminal" — for god agents

## Canonical build/boot sequence

```bash
# 1. Clone (already done; see logs/clone-olympus-616.log + artifacts/submodule-manifest.txt)
git clone --recursive https://github.com/olympus-616/olympus-616.git
cd olympus-616

# 2. Boot in reader mode
./olympus.sh
```

Per README §Boot, `olympus.sh` performs:
1. Check for `.env` (creates from `.env.example` if missing)
2. Verify all god submodules are populated (fetches missing repos)
3. Run `build.sh` to install dependencies and clear ports
4. Run `run.sh` to start the web launcher on `http://localhost:616`

Expected outcome: "31 services, 64 endpoints (API + UI per god), all green" at http://localhost:616.

## Dependencies on cosmos-logos org (per CLAUDE.md)

CLAUDE.md states the TurtleShell client apps were **migrated out of olympus-616** into the cosmos-logos org and are no longer submodules of olympus-616:

| Repo | Org |
|------|-----|
| turtleshell-web | cosmos-logos |
| turtleshell-ios | cosmos-logos |
| turtleshell-offgrid | cosmos-logos |

The olympus-616 boot does **not** depend on these clients (they consume the backend, not the other way around). For full system reconstruction the cosmos-logos repos must also be cloned, but the 31-service pantheon boot is self-contained within olympus-616.

## Branches (per CLAUDE.md)

- Main branch for olympus-616 repos: `brain/1.7.x.x` (NOT `main`)
- EOS-cycle development: `cycle/eos-<N>` shared across all repos in a cycle

## License

AGPL-3.0 (per README) — open source sovereign infra, fork/modify allowed, distribution requires source disclosure.

## Non-build directives noted (out of scope for build attestation, captured for completeness)

- `alchemisthomer.sh` — author mode entry point (not used here; this attestation is the *non-alchemisthomer* path)
- `cosmicturtle.sh` — cosmos-logos development agent
- `nextpage.sh` — cross-repo commit/merge tool
- `pantheon.json` — god manifest consumed by the launcher
- `spawn-config.json` — hardware profile (fast/standard/conservative)
