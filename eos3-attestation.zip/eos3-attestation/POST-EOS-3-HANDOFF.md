# Post-EOS-3 Optimization Agent — Handoff

**Cycle just completed:** EOS-3, 2026-06-11
**Next cycle target:** EOS-4 (date TBD per release cadence)
**Your role:** Phase B optimization agent. Take this bundle and ship the smallest possible PRs that eliminate findings so EOS-4 sees fewer.

This document is the canonical input prompt for the post-EOS-3 optimization agent. Paste the §"Agent prompt" section verbatim into a fresh Claude Code session in `/Users/gregory/dev/repos/` to start work.

---

## What landed in EOS-3

| Artifact | Purpose |
|---|---|
| `ATTESTATION.md` | Verdict, replay sequence, materials cloned, runtime curls. The top-level summary. |
| `FINDINGS.md` | 9 numbered findings, each tagged with SOC-2 / HIPAA / PCI / ISO 27001 control numbers. Each has a proposed fix. |
| `RUNBOOK-FROM-THE-VOID.md` | The external-human runbook. Sections marked `[in progress]` or `[pending]` are gaps to close. |
| `EOS_FRAMEWORK.md` | The three-phase framework (Claim & Verify → Optimize & Compact → Verify Again) and the compliance crosswalk that keeps it audit-ready. |
| `decisions/00*.md` | The judgment calls the attesting agent made. Read these before assuming a finding is "obviously" addressable — the rationale is in here. |
| `logs/build.log` | Forensic transcript. Look here when a finding is ambiguous. |
| `artifacts/sha256-manifest.txt` | Tamper-evidence over every file in the bundle. |

## Your deliverables (Phase B)

1. **One PR per finding, smallest possible change.** Repo is the natural owner per the finding's `Where:` field. Branch naming: `eos-improvement/finding-NNN` against `cycle/eos-3` if it's open, else `brain/1.7.x.x`.

2. **A `POST-EOS-3-COMPACTION-REPORT.md`** in this directory summarizing:
   - Which findings shipped PRs (with links).
   - Which findings you could not address and why.
   - Any new findings *you* discovered while implementing fixes.
   - Recommended target date for EOS-4.

3. **An updated `RUNBOOK-FROM-THE-VOID.md`** that incorporates the changes you shipped — so the runbook describes the *current* recipe, not the EOS-3 recipe.

## Constraints

- **No cosmetic-only PRs.** A whitespace fix that doesn't close a finding has no place here.
- **No bundled PRs.** One finding per PR keeps the audit trail per-control clean.
- **No commits or pushes by the agent.** Per the project's `feedback_no_commits` rule, only Gregory does git add/commit/push. Your job is to make the file edits and leave them staged-but-uncommitted for Gregory's review.
- **Preserve compliance tags.** When you update FINDINGS.md after fixing something, do NOT delete the finding — mark it `STATUS: closed by PR #NNN` and keep the original text. Audit trails are append-only.
- **Surface unknowns.** If a finding's "Fix:" section names a path you can't reason about (e.g., a Salesforce feature you've never heard of), do not guess — ask Gregory, and record the question in the compaction report.

## How EOS-4 will judge your work

EOS-4's Phase A will re-execute the full recipe. Your work is graded by three numbers:

1. **Findings closed** (delta from 9 → ?).
2. **Manual interventions Gregory had to make** during EOS-4 (should approach 0).
3. **Wall-clock time** from `git clone` to "system rebuilt and data flowing through olympus-gpt" (should monotonically decrease).

A perfect Phase B run is one where EOS-4 needs Gregory for zero clicks and finishes in under an hour. We are far from that today; the trend is the metric.

---

## Agent prompt

Paste this — verbatim — into a fresh Claude Code session:

```
You are the post-EOS-3 optimization agent (Phase B of the EOS framework). Your
sole purpose is to make the next attestation cycle (EOS-4) need fewer findings
and less of Gregory's time.

Read these files first, in order, before editing anything:
  1. /Users/gregory/dev/repos/eos3-attestation/POST-EOS-3-HANDOFF.md  (this file)
  2. /Users/gregory/dev/repos/eos3-attestation/FINDINGS.md             (your work list)
  3. /Users/gregory/dev/repos/eos3-attestation/EOS_FRAMEWORK.md        (the meta-framework)
  4. /Users/gregory/dev/repos/eos3-attestation/RUNBOOK-FROM-THE-VOID.md (the external recipe)
  5. /Users/gregory/dev/repos/eos3-attestation/decisions/              (judgment calls and why)

Then, for each finding in FINDINGS.md (work in numerical order):
  - Locate the repo + file the finding cites (the "Where:" field).
  - Read the "Fix:" proposal. If it still makes sense, implement it.
  - If it does NOT still make sense (the code has changed; the fix would
    break something else; the author missed context), propose a different
    fix in a comment on the finding and stop. Do not silently invent a
    different fix.
  - Make the file edits. Do NOT git add / commit / push — Gregory does
    that. Leave changes staged-but-uncommitted.
  - Record what you did in POST-EOS-3-COMPACTION-REPORT.md in this directory.

Hard rules:
  - One finding per round-trip to Gregory. Don't batch.
  - Preserve all compliance tags on findings; mark closed ones as
    "STATUS: closed by <PR-or-commit>" rather than deleting them.
  - If you can't address a finding (privilege, knowledge, judgment gap),
    explain why in the compaction report. That is also valuable Phase B
    output.
  - When you're done with all findings, update RUNBOOK-FROM-THE-VOID.md
    to reflect the new recipe (so EOS-4 sees the post-Phase-B world).

The work is graded by (1) findings closed, (2) Gregory's intervention count
during EOS-4, (3) EOS-4 wall-clock time. Optimize for those three.

When the compaction report is complete, stop and tell Gregory.
```

---

## Notes for Gregory

- This handoff doc, EOS_FRAMEWORK.md, and the cycle's bundle are now stable. EOS-3 is committed evidence.
- The Phase B agent's runtime is open-ended — could be one session, could be a /loop. Either works.
- After EOS-4 closes, this whole tree (eos3-attestation/) becomes archival evidence and is referenced from EOS-4's input bundle. Don't move it; don't edit it post-hoc except to add a `STATUS: closed by ...` annotation on a finding.
- Recommended next archive location: a separate read-append-only repo, e.g. `olympus-616/eos-evidence`, with signed commits and force-push disabled at the org level. That's the SOC-2 / HIPAA evidence vault.
