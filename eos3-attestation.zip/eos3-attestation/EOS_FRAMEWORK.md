# The EOS Attestation Framework — Compliance Overlay

**Important framing:** A full, project-canonical EOS cycle framework already exists at `olympus-616/foundation/eos/cycle/` with a 7-stage kanban (00_backlog → 01_planning → 02_design → 03_ready → 04_in_development → 05_verifying → 06_shipped) and a per-cycle template (`TEMPLATE.md`) covering §1 user story, §2 acceptance criteria, §5 governance gate, §6–§12 agent decomposition, §9 telemetry assertions, and §13 deferred gaps. The current cycle, **EOS-3**, lives at `04_in_development/brain_1.7.eos-3.md` with the verbatim Steward attestation statement:

> *"I attest the entire application can be constructed by accessing public GitHub repositories and following the instructions therein."*

This document does **not** replace that framework. It is a **compliance overlay** that maps the canonical framework's lifecycle into SOC-2, HIPAA, PCI DSS, and ISO 27001 control vocabulary so the existing cycle artifacts function as auditor-ready evidence without re-mapping per audit.

The compliance overlay reads the canonical artifacts as inputs:

| Canonical artifact | Compliance role |
|---|---|
| `foundation/eos/cycle/04_in_development/brain_1.7.eos-{N}.md` | Per-cycle scope, criteria, and verification record (Steward-authored top half + Agent-authored bottom half) |
| `06_shipped/brain_1.7.eos-{N}.md` | Immutable historical evidence (post-closure) |
| §2 acceptance criteria | The falsifiable claims under attestation |
| §5 approval gate | Governance approval evidence |
| §9 telemetry assertions | Continuous-monitoring evidence |
| §13 deferred gaps | Roadmap input to the next cycle |
| `Cycle__c` SObject rows | Karmic-accounting trail (audit-grade record of cost + outcome) |

This eos3-attestation bundle is **third-party-style evidence** for EOS-3's §2.1 (Node from void) and partial §2.4 (olympus-gpt round-trip) acceptance criteria — written from the perspective of an agent acting independently of the founder, recording every step.

---

## Mapping the canonical cycle to compliance frameworks

### SOC 2 (Trust Services Criteria)

| Criteria | Canonical EOS artifact that provides evidence |
|---|---|
| **CC1.1 (Control Environment)** | The canonical README + TEMPLATE.md document the operating discipline. |
| **CC2.1 (Communication)** | The cycle doc itself is the communication of objectives + procedures. |
| **CC2.3 (Communication with External Parties)** | The RUNBOOK-FROM-THE-VOID.md is the external-facing communication. |
| **CC3.4 (Risk Assessment - Vendor)** | §2 GIVEN clauses surface vendor dependencies (Salesforce, AWS, GitHub) explicitly. |
| **CC5.2 (Control Activities)** | §6–§12 agent decomposition specifies control activities for each cycle. |
| **CC5.3 (Policies)** | This file + the canonical README are the operative policies. |
| **CC6.1 (Logical Access)** | The §1.1 PoLP qualification — repos behind appropriate access controls — is the explicit access design. |
| **CC6.6 (Logical Access - Boundaries)** | This attestation's `GIT_CONFIG_GLOBAL` + `GIT_ASKPASS` pattern documents the boundary between attesting-agent identity and host credentials. |
| **CC7.1 (System Operations - Detection)** | §9 telemetry assertions + `npm audit` at build time. |
| **CC7.2 (System Operations - Anomaly Detection)** | §13 deferred-gaps log captures anomalies the cycle did not resolve. |
| **CC7.3 (System Operations - Evaluate Risk)** | Findings in this bundle, severity-ranked, are the risk evaluation. |
| **CC7.4 (System Operations - Recover)** | The whole attestation is a recovery rehearsal — rebuilding the system from source. |
| **CC8.1 (Change Management)** | Atomic squash-merge per cycle to `brain/1.7.x.x` IS the change-management discipline. |

### HIPAA Security Rule (applies if any god handles PHI)

| Citation | Mapping |
|---|---|
| §164.308(a)(1)(ii)(D) — Information System Activity Review | §9 telemetry assertions + the cycle's verification phase are the activity review. |
| §164.308(a)(3) — Workforce Security | §5 governance gate restricts cycle execution to approved actors. |
| §164.308(a)(8) — Evaluation | Each EOS cycle is a periodic technical+nontechnical evaluation. Findings are evaluation output. |
| §164.312(b) — Audit Controls | Forensic transcript (`logs/build.log`) + `Cycle__c` SObject + SHA-256 manifest are audit controls. |
| §164.312(c)(1) — Integrity | Tamper-evidence via SHA-256 + (recommended) GPG-signing of `ATTESTATION.md` |
| §164.316(b)(1) — Documentation | Cycle docs + RUNBOOK + this file are the required documentation. |

### PCI DSS v4 (applies to Plutus / billing pipeline if it touches PAN)

| Requirement | Mapping |
|---|---|
| **Req 6.2** — Ensure all system components are protected from known vulnerabilities | `npm audit` (Finding #4) at build time + each cycle Phase A = ongoing 6.2 evidence. |
| **Req 6.3.2** — Review custom code prior to release | §5 governance gate + §12 review checklist are the documented code-review cadence. |
| **Req 10.7** — Audit log retention | Build log + cycle docs + Cycle__c rows in production = audit log retention story. |
| **Req 11.3** — Implement a vulnerability management process | Findings → next cycle's §13 inheritance → re-verify is exactly a vulnerability-management process applied to deployment recipes. |
| **Req 12.10** — Incident response plan | A failed cycle closure is an incident; §13 captures the response. |

### ISO 27001 (Annex A controls)

| Control | Mapping |
|---|---|
| A.5.1 (Policies) | This file + foundation/eos/cycle/README.md are the operative policies. |
| A.5.10 (Acceptable use of information / assets) | RUNBOOK-FROM-THE-VOID.md constrains acceptable use of the build recipe. |
| A.5.15 (Access control) | The PoLP qualification (§1.1.b) is the explicit access-control design. |
| A.5.16 (Identity management) | Decision 001 (credential trust) + Decision 003 (GIT_ASKPASS pattern) document identity-management approach during build. |
| A.5.2 (Roles and responsibilities) | Steward writes top half; agent writes bottom half; sub-agents stay in their repos. |
| A.8.2 (Privileged access rights) | The four sf orgs (DevHub, prod, sandbox, scratch) with their distinct authorities are privileged-access design. |
| A.8.8 (Management of technical vulnerabilities) | npm audit (Finding #4) + dependency cycle. |
| A.8.16 (Monitoring activities) | §9 telemetry assertions + Finding #10 (swallowed errors) document the monitoring-detection design. |
| A.8.28 (Secure coding) | §12 review checklist + Phase B PRs that close findings = secure coding remediation cycle. |
| A.12.1.2 (Change management) | Atomic per-cycle squash-merge to `brain/1.7.x.x` = operational change control. |
| A.12.6.1 (Technical vulnerabilities) | Findings → Phase B → re-verify. |
| A.17.1 (Information security continuity) | The full from-the-void attestation IS a disaster-recovery rehearsal of the build process. |

---

## What "post-cycle" means in this framework

The canonical framework already handles post-cycle continuous improvement via two mechanisms:

1. **§13 deferred gaps** in the closing cycle doc — items not addressed in this cycle, prioritized into future cycles.
2. **Single-open-cycle global mutex** — when EOS-3 ships to `06_shipped/`, EOS-4 enters `01_planning/`. The kanban folder tree enforces the queue.

A "post-EOS-3 optimization agent" (the role this bundle's `POST-EOS-3-HANDOFF.md` describes) is therefore equivalent to **the EOS-4 cycle**'s agent, focused on the §13 inheritance from EOS-3 plus EOS-4's own scope. There is no separate parallel improvement track — the cycle IS the improvement loop.

(My earlier framing introduced a separate "Phase B optimization agent." That framing is *compatible* with the canonical framework — it describes the work that happens between cycles to prepare the §13 inheritance — but the canonical position is that this work IS the next cycle's pre-flight, not a parallel track.)

---

## Daily-dated evidence into eternity

Per the Steward directive: "we can use it as daily dated evidence from this day into eternity."

The canonical framework already provides:

- **Per-cycle dated artifacts** — the cycle doc in `06_shipped/` carries `Opened` and `Closed` dates and is immutable after closure.
- **`Cycle__c` SObject rows in production** — every cycle's record + cost + outcome lives in the operational data plane.
- **`LedgerEntry__c.Cycle__c` FK** — every karmic ledger event is traceable to the cycle that minted it.

The compliance overlay adds:

- **Per-attestation directory** like this one (`eos3-attestation/`), name-stamped with cycle ordinal + UTC date, retained without deletion.
- **SHA-256 hash of `artifacts/sha256-manifest.txt`** signed (recommend GPG or sigstore) by the attesting agent.
- **Push to a read-append-only archive** — recommended new repo `olympus-616/eos-evidence` with signed commits and force-push disabled at org level, where every cycle's bundle is committed and never modified.
- **Daily monitoring subset**: a headless cron that runs Phase 1 + Phase 2 of the runbook (clone + control-plane boot) every day and writes a dated success/failure marker. This is the "daily evidence" channel; it is *not* the full §2.1–§2.9 attestation, which happens at cycle close.

That combination — cycle-doc immutability in `06_shipped/`, attestation-bundle immutability in `olympus-616/eos-evidence`, daily monitoring marker — produces dated evidence from this day forward into eternity.
