# Build Your Own Olympus — From the Void

**Audience:** Any human with a laptop and a few hours, who wants to fork the system and run their own sovereign Olympus-Grid cluster against their own Salesforce scratch org — ending with `omens` running against the environment they just built.

**Status:** Living document. Sections still in `[in progress]` will be filled in as the EOS-3 attestation run completes. Where the attesting agent had to deviate from a clean fork-and-go path, the deviation is called out under `Gotcha`.

**Scope of this attestation (EOS-3):** Salesforce + control plane + cluster runtime, with **pre-existing AWS infrastructure assumed** (DNS, SSM, IAM, ECR, ECS — all provisioned in `cloudpremise-llm-managed-aws`). A fresh-AWS rebuild is the EOS-AWS-FROM-VOID cycle's job, not this one. See `decisions/006-aws-scope.md`.

---

## Prerequisites (one-time per machine)

| Tool | Version | Why |
|---|---|---|
| macOS or Linux (Windows requires translation) | recent | The recipe uses bash; Windows users follow with WSL2 + extra friction |
| git | 2.30+ | Clone with submodule support |
| GitHub CLI (`gh`) | 2.50+ | Auth — `gh auth login` |
| Node.js | 22.x (this run used `22.20.0`) | Launcher (Vite + Express) and god services |
| Salesforce CLI (`sf`) | 2.130+ (this run used `2.136.8`) | Scratch org create + metadata deploy |
| Xcode + Xcode CLI tools | 16+ | Only if you intend to ship omens to a physical iPhone |
| Godot 4.x | 4.2+ | Only if you intend to build the omens client yourself |
| jq | 1.6+ | For inspecting `sf` JSON output in this runbook's snippets |

### Accounts you need

1. **GitHub account.** A token with `repo` scope.
   - Public path: fork `cosmos-logos/*` repos (all public).
   - Private path: you also need read access to the `olympus-616/*` org repos. Today (2026-06-11) 46 of 48 are private. To follow this runbook in full, you must be a collaborator on the org. *Reproducibility gap — see [FINDINGS.md](FINDINGS.md) Findings #2 + #7.*

2. **Salesforce DevHub-enabled org.** Required for `sf org create scratch`. Three paths in increasing order of "from the void"-ness:
   - **Use an existing DevHub-enabled prod/sandbox.** Fastest if you already have one.
   - **Sign up for a free [Developer Edition](https://developer.salesforce.com/signup)** (~5 min including email verification). Then enable Dev Hub: Setup → Dev Hub → check "Enable Dev Hub". Optionally check "Enable Unlocked Packages and Second-Generation Managed Packages" for 2GP work.
   - **Sign up for a [trial Enterprise edition](https://www.salesforce.com/form/signup/freetrial-sales/)** (30-day) if you need higher scratch-org quota than DevEdition allows.

   Then auth your `sf` CLI to the DevHub:
   ```bash
   sf org login web --alias my-devhub --set-default-dev-hub
   ```

   The EOS-3 attestation used an existing DevHub (`cloudpremise-biz`). A fresh trial DevHub from sign-up works identically — but the email verification + Dev Hub enable step IS a human-required step that no agent can skip. This expectation must be captured in any future attestation that claims pure "from the void" — see [`POST-EOS-3-HANDOFF.md`](POST-EOS-3-HANDOFF.md) for the carry-forward to EOS-4.

3. **AWS access — out of scope for this cycle.** EOS-3 assumes the `cloudpremise-llm-managed-aws` account is already provisioned with SSM secrets, ECR repos, ECS cluster, and DNS records. If you are not a member of that AWS account, the runbook still produces a *local* working pantheon (Phase 2 + Phase 4 + Phase 5), and Phase 6's GPT smoke test can hit local endpoints — but anything ngrok/CloudFront/CDN related will need its own setup that the EOS-AWS-VOID cycle will document.

4. **Anthropic + (optional) OpenAI + xAI API keys.** Only required if you want Athena to call those provider LLMs. Ollama-only path needs no keys.

---

## Phase 1 — Clone the system from GitHub

Estimated time: ~1 minute (network bound).

```bash
mkdir -p ~/dev/repos && cd ~/dev/repos

# Auth your GitHub CLI if you haven't
gh auth login   # choose HTTPS protocol

# Clone the parent + all submodules in one go
git clone --recurse-submodules -j 8 https://github.com/olympus-616/olympus-616.git

# Plus the public cosmos-logos repos (TurtleShell clients, etc.)
mkdir -p cosmos-logos && cd cosmos-logos
for r in turtleshell-web turtleshell-offgrid thoth alpha resolver2; do
  git clone --recurse-submodules "https://github.com/cosmos-logos/$r.git"
done
cd ..
```

### Gotcha — submodule URLs are SSH

If `gh auth` is using a token (not SSH), the `--recurse-submodules` step will fail with `Permission denied (publickey)` for every submodule. `.gitmodules` pins URLs to `git@github.com:`. Workaround until [Finding #2](FINDINGS.md) is fixed:

```bash
# Tell git to rewrite SSH URLs to HTTPS for this clone
git config --global url."https://github.com/".insteadOf "git@github.com:"
# Then re-run the clones above
```

Better: have the project switch `.gitmodules` to `https://github.com/...` URLs.

---

## Phase 2 — Boot the Olympus-616 control plane

Estimated time: ~30 seconds (after the first `npm ci`).

```bash
cd ~/dev/repos/olympus-616
cp .env.example .env
bash build.sh      # npm ci at root, api/, ui/; clears ports 615+616
nohup bash run.sh > .pantheon/launcher.log 2>&1 &
```

Verify:

```bash
curl -s http://localhost:615/api | head -1                        # → <!DOCTYPE html>
curl -s http://localhost:615/api/gods | jq '.gods | length'       # → 33
```

You should see 1 self + 31 gods + 1 infrastructure entry = 33. All gods report `status: "idle"` until you click **Launch** on the UI at http://localhost:616.

### Gotcha — alchemisthomer.sh ≠ build.sh

The README's documented entry point is `./alchemisthomer.sh`, which ends by spawning a Claude Code CLI session whose *job* is to run the steps above. If you don't have `claude` installed, the script can't complete. Use the direct path shown here (`cp .env.example .env; bash build.sh; nohup bash run.sh ...`) — that's what `alchemisthomer.sh` would have asked Claude to do. See [Finding #1](FINDINGS.md).

---

## Phase 3 — Spawn a brand-new olympus-grid scratch org

Estimated time: 10–25 minutes (Salesforce scratch provisioning + 13-step deploy + Apex tests).

```bash
# Make sure sf is authed to a DevHub. Use yours, not cloudpremise-biz.
sf org list --all                       # confirm DevHub is Connected
sf config set target-dev-hub <your-hub-alias>

# Then from olympus-grid:
cd ~/dev/repos/olympus-616/olympus-grid
bash build.sh
```

What `build.sh` actually does:

1. Stops local olympus-grid Control Plane (ports 3441–3444)
2. `npm ci` at olympus-grid root + api/ + ui/
3. Runs `scripts/bash/env/createBrandNewDevEnterpriseScratchOrg.sh`, which:
   - Calls `removeReactforceMetadata.sh`
   - Calls `org_remove.sh dev_enterprise` — **destroys any existing scratch org aliased `dev_enterprise`**
   - Calls `loadDevEnterpriseScratchOrg.sh` — provisions a fresh one with namespace `(none)` per `orgs/dev-enterprise.json`, 30-day expiration
   - Deploys: source metadata, Connected App, BPM queues, BPM config, Proteus objects, Orion threads
   - Assigns permsets: `Olympus_Grid_Admin`, `Olympus_Grid_API_Admin`, `Turtleshell_Admin`
   - Runs the full test suite

### Gotcha — the deploy script swallows compile errors

[Finding #10](FINDINGS.md): real Apex compile errors (`Field does not exist:` etc.) are logged but produce ✅ COMPLETE in stdout. If you only watch exit codes, you'll believe the deploy was clean. Check the build log (`olympus-grid/logs/build_*.log`) for `Error (executeCompileFailure)` or `Field does not exist` lines. EOS-3 surfaced three such errors during this very phase.

### Manual configuration — REQUIRED before any surface can route

Do these in Salesforce Setup AFTER the build script completes. The first one is the keystone — **without it the entire downstream system silently fails to route requests** (Finding #17). The deploy script does NOT verify it was set. The build's post-build scanner does not warn you.

1. ⚠️ **Set PortalSiteUrlRewriter — CRITICAL, BLOCKS EVERYTHING DOWNSTREAM**
   Setup → Sites → click your Site → Edit → **URL Rewriter Class** = `PortalSiteUrlRewriter`. Save.
   Verify: at this point, navigate to your scratch org's portal URL (`https://<...>.scratch.my.site.com/portal/`) and confirm it does NOT 404. If it 404s, this step did not save.
   This is the single most important manual click in the entire runbook. Without it, omens / gpt / turtleshell-* / iris-portal will all appear to load but cannot complete a single routed request. See [Finding #17](FINDINGS.md).
2. **Set logout URL** — Setup → Identity Provider / Network → set the absolute logout URL.
3. **Verify guest user email** — for Web2Case outbound email. Setup → Org-Wide Email Addresses → verify the guest sender.
4. **Add Azure redirect URL** — only if you want Microsoft login. In Azure Portal → App Registrations → your app → Redirect URIs → add your scratch org's `/services/authcallback/Microsoft` URL.
5. **Verified email domain** — Setup → Home → Connect → **Set Up**. Add and verify your sending domain. Required for any outbound email surface (Hermes messaging, Web2Case, account-verification, cosmos-logos email channels). Not in the script's REMINDER block — surfaced by the scratch org Setup UI itself during EOS-3 (see Finding #12).

Steps 2–4 are flagged in `loadDevEnterpriseScratchOrg.sh`'s own REMINDER block. Step 1 is too — but its severity is underrepresented there; it is recorded as Finding #17 with blocker severity. Step 5 is documented nowhere in the script.

---

## Phase 4 — Configure the pantheon to talk to your scratch org

Estimated time: < 1 minute.

The Hermes god auto-discovers the scratch org by reading `olympus-grid/.agent/org-info.json`. The file is written by `capture-org-info.sh`. Run it once after the scratch org exists:

```bash
cd ~/dev/repos/olympus-616/olympus-grid
bash scripts/bash/env/capture-org-info.sh dev_enterprise
cat .agent/org-info.json    # expect: orgId, instanceUrl, siteUrl, username, alias
```

Expected shape:

```json
{
  "orgId": "00DEc00000gNSec",
  "instanceUrl": "https://cloudpremise.my.salesforce.com",
  "siteUrl": "https://innovation-app-NNNN.scratch.my.site.com/portal",
  "username": "test-XXXXXXXXX@example.com",
  "alias": "dev_enterprise",
  "status": "Active",
  "expirationDate": "YYYY-MM-DD",
  "capturedAt": "YYYY-MM-DDTHH:MM:SSZ"
}
```

How the rest of the system uses this file:
- `hermes/api/src/util/grid-master.ts` reads `siteUrl` (falls back to deriving from `instanceUrl`).
- `iris/reactforce/olympus-grid-ai/src/lib/nodes.ts` reads it for portal dev mode.
- `omens/tools/ios-deploy.sh` reads it for iPhone install configuration.
- Override anywhere via env var `OLYMPUS_GRID_MASTER_URL=https://your-host` (production override).

Cross-Origin: `ares/api/src/index.ts` accepts any `*.scratch.my.site.com` host by regex, so the new scratch org's ephemeral URL passes ARES security without redeployment. (This is a documented EOS-3 fix already in the codebase — see the comment block at `ares/api/src/index.ts` line 65.)

---

## Phase 5a — Local dev launcher (optional sanity check, NOT the test target)

Estimated time: ~30 seconds for the launcher's spawn pass; gods continue warming up in the background.

Pressing **Launch** on http://localhost:616 spawns the 31 gods *on your local host*. This is useful for development sessions but it is **not** what EOS-3 verifies (see [decisions/007-local-gods-not-test-target.md](decisions/007-local-gods-not-test-target.md)). EOS-3's §2.x acceptance criteria are about surfaces reaching the **cloud cluster** spawned from the iris admin UI (Phase 5b below), not the local pantheon.

If you press Launch:
- 31 terminal windows open, one per god
- Most gods come up; some will fail because they expect API keys (Anthropic, OpenAI, AWS credentials) you haven't set in `.env`
- Hermes/Iris/omens still auto-discover the new scratch org via `.agent/org-info.json` — that part works
- It is fine to skip this entirely and proceed straight to Phase 5b

### Gotcha — the Launch button has no readiness gate

[Finding #11](FINDINGS.md): the Launch button is enabled regardless of whether the cluster is configured. If you press it before running `capture-org-info.sh` (Phase 4), the gods boot pointed at default config — they appear "online" in the dashboard but Hermes points at the wrong backend. The fix proposed in Finding #11 is to gate the button on a `cluster.ready` field that the `/api/gods` endpoint adds.

---

## Phase 5b — Spawn the realm (AWS Pantheon cluster) from the iris admin UI

**This is the §2.2 acceptance work** — the actual test target of EOS-3.

Estimated time: 5–15 min for Fargate to pull the Pantheon image and report healthy.

Once §2.1 closure is confirmed and `.agent/org-info.json` exists, the iris admin UI (inside the new scratch org) is where you provision the AWS cluster:

1. Open the scratch org as the admin user:
   ```bash
   sf org open --target-org dev_enterprise --path /lightning/n/Olympus_Grid
   ```
2. Navigate to the iris admin → Clusters page (the EOS-2 mechanism). Type a cluster name (e.g., `athena-eos3` — must match `^[a-z][a-z0-9-]{1,30}[a-z0-9]$`).
3. Click **Spawn**. Behind the scenes:
   - iris UI POSTs to `ApiRouteClusters.cls` → `handleSpawn`
   - A `Cluster__c` row is created with `Status__c='Provisioning'`
   - The cluster-runtime backend (AWS Fargate in `cloudpremise-aws` runtime) pulls the Pantheon image from ECR (`olympus-616/pantheon`)
   - As tasks come up, `Cluster__c.Status__c` transitions to `Live` and the cluster URL is populated
4. Wait for `Status__c='Live'` in the UI (or via SOQL: `SELECT Id, Name, Status__c, Url__c FROM Cluster__c ORDER BY CreatedDate DESC LIMIT 1`).

**§2.2 acceptance:** `Cluster__c` row exists with `Status__c='Live'`, Pantheon image pulls cleanly, every health endpoint returns 200, session log carries `cluster.manifested.ec2_pantheon` with `ClusterName__c`.

**AWS scope caveat (Decision 006):** the AWS account is pre-configured. You are using `cloudpremise-llm-managed-aws` for this attestation. A fresh AWS account is the EOS-AWS-VOID cycle's job. For EOS-3, the AWS path is "given."

---

## Phase 6 — Smoke-test data flow via olympus-gpt against the cloud cluster

This is the §2.4 acceptance gate.

Estimated time: ~5 min.

1. Open olympus-gpt — the URL depends on your deployment but for the new scratch org it's reachable via the portal's app launcher under the `Plugin.app_olympus_gpt` LWC app. (For a managed-package install, it's also at https://your-instance.scratch.my.site.com/portal/s/olympus-gpt.)
2. Sign into the new scratch org as the admin user. The cosmos-logos handshake fires against the cluster URL captured in §2.2.
3. Join the realm (your `athena-eos3` cluster) — the gpt surface should auto-detect it from `.agent/org-info.json` and the `Cluster__c` row.
4. Issue at least one command against the realm's Pantheon fleet (e.g., a chat message that hits Athena).
5. Submit feedback through the gpt feedback widget.

**§2.4 acceptance:** A `Feedback__c` row exists in the new scratch org with `Source__c='olympus-gpt'` and the session-log attachment intact. Verify with:

```bash
sf data query --target-org dev_enterprise \
  --query "SELECT Id, Source__c, CreatedDate, (SELECT Id, Title, ContentType FROM Attachments) FROM Feedback__c WHERE Source__c = 'olympus-gpt' ORDER BY CreatedDate DESC LIMIT 5"
```

---

## Phase 7 (optional) — Build omens for your iPhone [pending]

[To be filled in by the attestation run if pursued, or marked as a documented gap if stopped at Phase 6.]

---

## What you have at the end

If you completed Phase 6: a sovereign Olympus-Grid running on your hardware, pointed at a Salesforce org you own, with a chat application (olympus-gpt) you can hit and watch the data land in your scratch org.

If you also completed Phase 7: `omens` running on your physical iPhone against the cluster you just built — the literal acceptance criterion of "I rebuilt this from the void."
