---
id: 001
title: GitHub credential trust caveat
timestamp_utc: 2026-06-11T14:34:42Z
---

# Decision 001 — GitHub credential trust

## Observation

`gh auth status` at attestation start showed the active GitHub account as `alchemisthomer` (the founder), with SSH-based git operations. Two additional accounts (`root-of-trust`, `gregprocasemgmt`) are also authenticated on this host.

## Implication

A strict "from the void" reconstruction would be performed by an identity with no prior relationship to the founder — e.g. a fresh GitHub user granted only the access required to clone public repos and any explicitly-shared private repos. Building under the founder's own credentials means private repos can be reached that an external party could not reach.

## Decision

Proceed with the current credentials for this attestation run, but flag the caveat. For SOC-2 evidence:

- Every `git clone` will be recorded with the repo's visibility (public vs. private) so the auditor can distinguish what a fully external party could and could not have reproduced.
- A second pass using a fresh, scope-limited identity is recommended before SOC-2 audit submission. This run establishes the build *recipe*; the second run establishes *external reproducibility*.

## Rationale

The attesting agent is acting independently of the founder's `alchemisthomer.sh` agent and is recording every step. That establishes process independence even if credential independence is deferred to a follow-up run.
