---
id: 003
title: Submodule URLs hardcode SSH; attestation isolates with GIT_CONFIG_GLOBAL
timestamp_utc: 2026-06-11T14:37:30Z
---

# Decision 003 — Submodule SSH URLs vs. token-based reproducibility

## Observation

`olympus-616/olympus-616/.gitmodules` pins all 38 submodules with `git@github.com:` SSH URLs (one exception: `olympus-grid-www` is HTTPS). On a fresh host where the build is performed with only a GitHub token (no SSH key trusted on github.com), the recursive clone fails for every SSH-pinned submodule with `Permission denied (publickey)`.

On the current host, a secondary issue compounds the problem: `~/.ssh/config` for `github.com` references `PKCS11Provider /Users/gregory/.ssh/alchemisthomer_odyssey2`, but that file is a normal SSH private key, not a PKCS11 library. SSH fails before it can try password/agent auth. (This is a host-specific misconfiguration, not a system-design issue.)

## Reproducibility implication

For an external party rebuilding "from the void" with only a GitHub token, the SSH-pinned `.gitmodules` is the actual blocker. The fix is either:

1. Rewrite `.gitmodules` to use `https://github.com/...` URLs (recommended — works everywhere a token works).
2. Document a token-bearing build recipe that uses a `url.https://github.com/.insteadOf git@github.com:` config rewrite per-invocation (what this attestation will do).

The `cosmos-logos` org submodule URLs should be audited the same way once we examine them.

## Decision

For this attestation run:

- Write an attestation-local `gitconfig` at `eos3-attestation/environment/attestation.gitconfig` that:
  - rewrites `git@github.com:` to `https://github.com/` so every clone (including submodules) uses HTTPS
  - supplies a credential helper that hands the gh-issued token to git for `github.com`
  - sets a sentinel `user.name = eos3-attestation-agent` / `user.email = attestation@olympus-616.local` so any inadvertent commits are obviously identifiable
- Set `GIT_CONFIG_GLOBAL` to that file for every git invocation in this attestation run, fully replacing the host's `~/.gitconfig` for the build. This guarantees the recorded recipe is independent of host-local git config.

## Recommendation for the project

`olympus-616/.gitmodules` should be migrated to `https://github.com/...` URLs before the SOC-2 audit (or a documented `setup.sh` wrapper that performs the rewrite should ship in the repo). Otherwise the README's "one command" claim does not hold for token-only operators, even with full access.
