---
id: 002
title: Scope of private repositories
timestamp_utc: 2026-06-11T14:36:00Z
---

# Decision 002 — Private repository scope

## Observation

The two GitHub orgs in scope contain:

| Org           | Total | Public | Private |
|---------------|-------|--------|---------|
| olympus-616   | 48    | 2      | 46      |
| cosmos-logos  | 6     | 6      | 0       |

Only `olympus-616/foundation` and `olympus-616/olympus-grid-www` are publicly cloneable from olympus-616. The remaining 46 repos — including the main entry point `olympus-616/olympus-616`, the Greek-pantheon service repos (zeus, hera, athena, apollo, ares, hermes, …), and the platform-specific TurtleShell repos — require explicit access.

The cosmos-logos org is fully public.

## Implication

A "from the void" build performed under unrelated credentials would currently fail at the first `git clone` of `olympus-616/olympus-616`. The build *is* reproducible from GitHub by anyone holding the appropriate access, but the artifact is not fully open.

## Decision

Two attestation tracks are required for full SOC-2 evidence:

1. **This run (process attestation):** Demonstrates the build recipe is encoded in code, not in the founder's head, by executing it under an independent agent. The fact that the credentials happen to be the founder's does not undermine this — the agent is following published instructions, not founder guidance.
2. **External reproducibility track (deferred):** A second build under a scope-limited identity granted read access to exactly the repos required, with no other privileges. That run will produce the auditor-facing "external party can rebuild" evidence.

Both tracks should be retained in the SOC-2 evidence package.

## Default-branch note

Default branches across these repos are non-conventional: `brain/1.7.x.x` for most, `inception` for `turtleshell-offgrid`, `brain/7777` for `cosmos-logos/alpha` and `cosmos-logos/resolver2`. All clone commands in this attestation will explicitly capture the resolved default branch and HEAD SHA for each repo.
