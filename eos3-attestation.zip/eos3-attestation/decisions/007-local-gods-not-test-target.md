---
id: 007
title: Local-host gods are operational infrastructure, NOT the EOS-3 test target
timestamp_utc: 2026-06-11T17:15:00Z
---

# Decision 007 — Scope: local pantheon vs. cloud cluster

## Observation

Steward clarification (verbatim, 2026-06-11):

> "we are validating the end to end development environment but we are not validating the local gods that are launching currently. that would require us to route into localhost or through ngrok and the point of the test we are fully evaluating the cluster spins up correctly and the services work on the cluster"

## Implication

Pressing **Launch** on http://localhost:616 spawns the 31 gods *locally* on this host. Those local processes are useful for development sessions (the alchemisthomer / olympus-616 mode this whole attestation has been about), but they are *not* what EOS-3 §2.1–§2.9 is verifying.

EOS-3 §2.2 explicitly calls for a **realm (cluster) spawned from the node** via the iris admin UI's "spawn AWS Pantheon cluster" action (the EOS-2 mechanism). Once that AWS cluster is up:

- Surfaces (omens, gpt, turtleshell-*, iris portal) route their requests to **the cloud cluster**, not localhost.
- The §2.3–§2.8 feedback round-trips are validated against **the cloud cluster's Ares → Hermes → Athena chain**, not the local one.
- A local Athena that responds to a local curl is *not* evidence for any EOS-3 surface criterion.

## Decision

This attestation does NOT verify the local gods after Launch. Specifically:

- I will not curl localhost:34xx god endpoints as if they constitute §2.x evidence.
- I will not spend findings budget on local god failure modes (missing API keys, unconfigured providers, Ollama-dependency stalls, etc.) — those are operational issues for development sessions, separately findings-worthy but not in scope for the §2.x acceptance verdict.
- I *will* verify the local launcher's `/api/gods` reports them as transitioning out of `idle` (mechanical evidence that the spawn-and-monitor loop works), and I will note any that obviously failed for the development-environment finding pile.

What I WILL focus on:

1. **§2.1 closure proof** — confirm the scratch org is reachable, the iris-admin Plugin__mdt records exist, the canonical apps (`Plugin.app_iris`, `Plugin.app_guardians`, `Plugin.app_olympus_gpt`, `Plugin.app_turtleshell`) are installed.
2. **§2.2 cluster spawn** — find the iris admin UI's spawn-cluster action, trigger it (or document the Steward triggering it), watch for the `Cluster__c` row in the scratch org with `Status__c='Live'` and `ClusterName__c` populated.
3. **§2.4 olympus-gpt against the cloud cluster** — once the cluster is live, hit the gpt surface, sign into the new scratch org, issue commands, submit feedback. Acceptance is the `Feedback__c` row arriving in the new scratch org.

## Implication for the RUNBOOK

`RUNBOOK-FROM-THE-VOID.md` Phase 5 ("Spawn the 31 gods") needs to be reframed:

- **Locally** — pressing Launch is a dev-environment-readiness signal, not a system-acceptance signal.
- **Cloud cluster** — the actual §2.2 acceptance work is in the iris admin UI inside the new scratch org. Phase 5 should rename to "Spawn the realm (AWS Pantheon cluster) from the iris admin UI" with the cloud as the target.

I'll update Phase 5 + add a Phase 5b for "Local dev launcher (optional sanity check)" so the runbook reflects both, with the cloud as the EOS-3 verdict-bearing path.
