---
id: 005
title: build.sh destructively recreates dev_enterprise; pre-state recorded
timestamp_utc: 2026-06-11T16:35:00Z
---

# Decision 005 — Destroying the existing dev_enterprise scratch org

## Observation

`olympus-grid/build.sh` → `createBrandNewDevEnterpriseScratchOrg.sh` removes the existing `dev_enterprise` scratch org (via `scripts/sf/org_remove.sh dev_enterprise`) and recreates it via `loadDevEnterpriseScratchOrg.sh`.

Prior state of `dev_enterprise` (captured to `artifacts/dev_enterprise-PRE-STATE.json`):

```json
{
  "alias": "dev_enterprise",
  "username": "test-h08tjndwpdsq@example.com",
  "orgId": "00DRL00000QzdOr2AJ",
  "status": "Active",
  "instanceUrl": "https://innovation-app-8526.scratch.my.salesforce.com",
  "expirationDate": "2026-07-09",
  "createdDate": "2026-06-09T18:26:43.000+0000",
  "edition": "Enterprise"
}
```

This org was created 2 days before this attestation run (2026-06-09 → 2026-06-11). It is presumed to be in active development use by Gregory.

## Decision

Per the user directive — "the attestation continues until omens game is running from an olympus-grid cluster spawned from a **brand new** olympus-grid development org (salesforce scratch org)" — the existing `dev_enterprise` will be destroyed and recreated.

The pre-state JSON above is sufficient evidence of what existed before, in case the prior org needs to be referenced for any reason. The user can request a fresh attestation run that uses a different alias (e.g., `eos3_attest_dev`) to preserve the current `dev_enterprise` if circumstances change.

## What gets destroyed

- The Salesforce scratch org `00DRL00000QzdOr2AJ` (innovation-app-8526.scratch.my.salesforce.com) and all data inside it
- The local sf CLI auth record for `dev_enterprise`
- Any uncommitted Salesforce metadata in that org

## What is preserved

- All local repo state under `/Users/gregory/dev/repos/`
- All other scratch orgs and authenticated sandboxes
- The dev hub `cloudpremise-biz`
- The running olympus-616 launcher on ports 615/616

## Roadmap finding (recorded)

**FINDING-008:** `loadDevEnterpriseScratchOrg.sh` contains an embedded "REMINDER" of four manual configurations the script cannot perform via API:

1. Set `PortalSiteUrlRewriter` under Force.com Site Settings (not API-accessible)
2. Set logout URL in Network settings (must be an absolute URL)
3. Verify guest user email for Web2Case outbound email support
4. Add correct Azure redirect URL for Microsoft login in Azure App Registration

Each is a gap in the "from the void" attestation: a human reproducing this recipe must perform these clicks manually. For SOC-2 evidence, either (a) document them precisely in the RUNBOOK, (b) build automation around them (e.g., Metadata API where supported, Selenium/Playwright where not), or (c) accept them as "out of band" with a documented rationale.
