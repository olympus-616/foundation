---
id: 004
title: alchemisthomer.sh terminates by spawning a Claude Code session — perform the build directly instead
timestamp_utc: 2026-06-11T14:46:00Z
---

# Decision 004 — Direct execution vs. spawning nested Claude

## Observation

`olympus-616/alchemisthomer.sh` (and every mode flag it accepts) ends with `exec claude --dangerously-skip-permissions --append-system-prompt "$PROMPT" "$BOOT"`. The downstream Claude session is then expected to:

1. Copy `.env.example` → `.env` if missing
2. Verify pantheon submodules are populated
3. Run `bash build.sh`
4. Run `bash run.sh` in the background
5. Report status

The launch script itself does not perform the build; it delegates to a fresh Claude session.

The script also includes explicit warnings: "Do NOT run any launch.1.7.x.x.sh scripts yourself. That would create a nested Claude session which will crash" — i.e. the system already knows that running the orchestration scripts from inside an existing Claude session is forbidden.

## Implication

For this attestation, "executing `./alchemisthomer.sh`" inside an existing Claude Code session would either:
- Fork a second Claude Code process (the warned-against nested-session crash), OR
- Burn time on the Ollama preflight then fork that Claude session anyway

Neither produces audit-quality evidence of the build succeeding — the spawned Claude session's output is not captured in this attestation log.

## Decision

The attesting agent (this Claude session) will play the role of the alchemisthomer-spawned agent and perform STEP 0–STEP 4 directly:

1. `cp .env.example .env`
2. (Skip submodule fetch — already done with `--recurse-submodules` in step 2.)
3. `bash build.sh`
4. `nohup bash run.sh > .pantheon/launcher.log 2>&1 &`
5. `curl http://localhost:615/api` and `curl http://localhost:616/` for runtime attestation

Ollama preflight will be **inlined** into this attestation — the same install/pull/test commands the script runs — so the documented recipe is honored. The Ollama install runs in parallel with build.sh in the background, since the launcher itself does not require Ollama (only the Athena god does, and gods are spawned by clicking Launch on the UI, not by build.sh).

## Roadmap finding (EOS-3)

**FINDING-001:** The build recipe assumes Claude Code is installed as a prerequisite. A reviewer who follows `./alchemisthomer.sh` cannot stand up the system without first installing the `claude` CLI. For SOC-2, the system-build path should be expressible without dependence on a specific AI CLI. Recommendation: factor a `bash bootstrap.sh` that runs STEP 0–STEP 4 directly (env+build+run) and have `alchemisthomer.sh` call it before exec'ing claude. The exec-claude step becomes "open an interactive author session against the now-running system," not "ask a fresh agent to build the system."
