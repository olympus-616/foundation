---
id: 006
title: AWS infrastructure scope — pre-configured cloudpremise org, not "from the void"
timestamp_utc: 2026-06-11T16:48:00Z
---

# Decision 006 — AWS scope for EOS-3

## Observation

Per user directive received mid-Phase-2:

> "this is a pre-configured aws org. aws from the void is out of scope of this test cycle. there are already a number of elements setup related to dns and ssm at a minimum, maybe more. cloudpremise llm managed aws is the only in scope aws organization for the scope of this test and we will move aws from fresh aws account in a future cycle"

## Implication

The EOS-3 attestation's "from the void" claim is **bounded to the Salesforce + control-plane + cosmos-logos surfaces**. AWS dependencies (Zeus CDK stacks, ECR images, ECS services, SSM parameter store, CloudFront/DNS records under cloudpremise.com domains, IAM roles, etc.) are *assumed* to exist in their already-provisioned state in the `cloudpremise-llm-managed-aws` account.

A reviewer attempting to replay this attestation in a fresh AWS account will hit gaps. Those gaps are intentionally deferred to a future EOS cycle (working name: **EOS-AWS-FROM-VOID** or **EOS-5**).

## Decision

- The RUNBOOK-FROM-THE-VOID.md should call out, at the top of any AWS-touching section, that the recipe assumes pre-existing AWS resources and links to the cloudpremise account scope.
- FINDINGS.md does NOT count AWS-prerequisite gaps in this cycle's finding total. They are catalogued separately in `out-of-scope-AWS.md` (to be created) so a future cycle inherits the list.
- The EOS_FRAMEWORK.md's cycle taxonomy now formally distinguishes:
  - **EOS-3 (this cycle):** SF + control plane + cluster runtime, AWS *given*.
  - **EOS-AWS-VOID (future):** Same recipe but starting from a fresh AWS account (no SSM, no IAM, no DNS records).
- The compliance crosswalk in EOS_FRAMEWORK.md should note that SOC-2 / HIPAA / PCI / ISO 27001 evidence for AWS infrastructure controls comes from a *different* attestation track — likely AWS Artifact + cloudpremise's own existing audits — and not from this cycle.

## Roadmap note (deferred to EOS-AWS-VOID)

Items recorded here for the future cycle's inheritance:
- SSM parameter creation (`/olympus/{env}/keys/COSMOS_LOGOS_*`, `/olympus/{env}/keys/COSMOS_LOGOS_POSEIDON_*`, etc.)
- ECR repository creation (`olympus-616/pantheon`)
- ECS cluster + service definitions (via Zeus CDK)
- ALB + path-based routing rules
- CloudFront distributions
- Route 53 zones and records (templeathena.ai, athena-616.ngrok.io subdomains, olympus-grid.com)
- IAM roles for CDK deploy and ECS task execution

Each is provisioned today via the `zeus/cdk/lib/*.ts` stacks; the "from-the-void" attestation of those stacks is the EOS-AWS-VOID job.
